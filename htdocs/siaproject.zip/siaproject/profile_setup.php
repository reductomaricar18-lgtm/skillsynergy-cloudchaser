<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// DB Connection
$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Fetch user_id
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($user_id);
if (!$stmt->fetch()) {
    $stmt->close();
    $conn->close();
    header("Location: login.php");
    exit();
}
$stmt->close();

// If the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize form inputs
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $personal_email = $conn->real_escape_string($_POST['personal_email']);
    $contact_number = $conn->real_escape_string($_POST['contact_number']);
    $location = $conn->real_escape_string($_POST['location']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $age = (int)$_POST['age']; // Ensure age is treated as an integer
    $availability = $conn->real_escape_string($_POST['availability']);
    $bio = $conn->real_escape_string($_POST['bio']);
    $college = $conn->real_escape_string($_POST['college']);
    $course = $conn->real_escape_string($_POST['course']);
    $status = $conn->real_escape_string($_POST['status']);
    $year = $conn->real_escape_string($_POST['year']);
    $block = $conn->real_escape_string($_POST['block']);

    // Update users_profile table
    $update_query = "UPDATE users_profile 
                     SET first_name = '$first_name', last_name = '$last_name',
                         personal_email = '$personal_email', contact_number = '$contact_number', 
                         location = '$location', gender = '$gender', age = $age,
                         availability = '$availability', bio = '$bio', 
                         college = '$college', course = '$course', 
                         status = '$status', year = '$year', block = '$block' 
                     WHERE user_id = $user_id";

    if ($conn->query($update_query) === TRUE) {
        // Prepare for assessment redirection
        if (isset($_POST['assessment_redirect'])) {
            // Save the form data to session
            $_SESSION['profile-setup-form'] = $_POST;
            header("Location: initial_assessment.php");
            exit();
        }

        // Mark profile as completed in users table
        $complete_query = "UPDATE users SET profile_completed = 1 WHERE user_id = $user_id";
        if ($conn->query($complete_query) === TRUE) {
            $_SESSION['profile_completed'] = 1;
            unset($_SESSION['profile-setup-form']); // Clear form data after saving
            header("Location: dashboard.php");
            exit();
        }
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}

// Fetch any existing assessment records for this user
$assessments = [];
$result = $conn->query("SELECT category, skill, proficiency FROM initial_assessment WHERE user_id = $user_id");
while ($row = $result->fetch_assoc()) {
    $assessments[$row['category']][$row['skill']] = $row['proficiency'];
}

// Philippine places for dropdown
$philippines_places = [
    "Manila", "Quezon City", "Caloocan", "Pasig", "Makati", "Taguig", "Pasay", "Parañaque",
    "Las Piñas", "San Juan", "Mandaluyong", "Marikina", "Muntinlupa", "Navotas", "Valenzuela"
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SkillSynergy Profile Set-up</title>
    <style>
    * {
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
    }

    body {
      background: url('SSS.jpg') no-repeat center center fixed;
      background-size: cover;
    }

    .container {
      max-width: 900px;
      margin: 20px 0 20px auto;
      display: flex;
      align-items: flex-start;
      justify-content: flex-end;
      padding-right: 35px;
      padding-top: 20px;
    }

    .form-section {
      background: rgba(255, 243, 243, 0.35);
      border-radius: 18px;
      padding: 13px;
      width: 830px;
      box-shadow: 0 3px 14px rgba(0, 0, 0, 0.25);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.25);
    }

    .card {
      background: rgba(255, 243, 243, 0.35);
      border-radius: 18px;
      padding: 3px 3px;
      margin-bottom: 12px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
    }

    .card h2 {
      font-size: 22px;
      margin-bottom: 14px;
      border-bottom: 2px solid #007acc;
      display: inline-block;
      padding-bottom: 4px;
      margin-left: 20px;
    }

    .card h2 span {
      color: #007acc;
      font-size: 26px;
    }

    .form-group {
      display: flex;
      flex-wrap: wrap;
      gap: 5px;
      margin-bottom: 12px;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      flex: 1 1 130px;
      padding: 8px 14px;
      border-radius: 18px;
      border: 1px solid #ccc;
      font-size: 14px;
      color: #666;
    }

    .form-group select option:first-child {
      color: #999;
    }

    .form-group textarea {
      flex: 1 1 100%;
      resize: none;
      height: 60px;
      border-radius: 15px;
    }

    .inline-group {
      display: flex;
      gap: 10px;
      flex: 1 1 130px;
    }

    .inline-group input {
      padding: 8px 14px;
      border-radius: 18px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .submit-btn, .skills-btn, .add-btn {
      border: none;
      border-radius: 25px;
      font-size: 14px;
      cursor: pointer;
      transition: 0.3s ease;
    }

    .submit-btn {
      background-color: #bbb;
      color: #fff;
      padding: 10px 28px;
      display: block;
      margin: 12px auto 0;
    }

    .submit-btn:hover {
      background-color: #999;
    }

    .skills-btn {
      background-color: #007acc;
      color: #fff;
      padding: 10px 24px;
      flex: 0 0 auto;
      display: block;
      margin: 0 auto;
    }

    .skills-btn:hover {
      background-color: #005f9e;
    }

    .fixed-submit-btn {
      position: absolute;
      top: calc(100% + 10px); /* 50px below the last content */
      left: 50%;
      transform: translateX(-50%);
      z-index: 999;
    }

    .add-btn:hover {
      background-color: #3e8e41;
    }

    .age-select {
      flex: 1 1 130px;
      padding: 8px 14px;
      border-radius: 18px;
      border: 1px solid #ccc;
      font-size: 14px;
      color: #666;
    }

.add-btn {
  width: 40px;
  height: 40px;
  background-color: #bdc3c7;
  color: #2c3e50;
  border: none;
  border-radius: 50%;
  font-size: 20px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 12px;
}

.add-btn:hover {
  background-color: #95a5a6;
}

.add-btn:active {
  background-color: #7f8c8d;
  transform: scale(0.95);
}

.add-btn:disabled {
  background-color: #ecf0f1;
  color: #bdc3c7;
  cursor: not-allowed;
}

    .skills-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 8px;
      position: relative;
    }

    .bio-textarea {
      flex: 1 1 320px;
      padding: 8px 14px;
      border-radius: 15px;
      border: 1px solid #ccc;
      font-size: 14px;
      color: #666;
      height: 60px;
      resize: none;
    }

    .bio-textarea:valid,
    .form-group input {
      color: #000;
    }

    select {
      color: #999;
    }

    /* Turn select text black after selecting a valid option */
    select:valid {
      color: #000;
    }

    button.removeSkill {
      margin-left: 10px;
      color: white;
      background: red;
      border: none;
      padding: 5px 10px;
      cursor: pointer;
      border-radius: 5px;
    }

.assessment-button-container span {
  display: inline-block;
  margin-top: 10px;
}

#main-assessment-btn {
  justify-content: center !important;
  margin-top: 15px;
  margin-left: 320px;
}
#assessment-btn {
  display: inline-block; /* or block */
}
  </style>
</head>
<body>

<div class="container">
  <form id="profile-setup-form" action="save_profile.php" method="POST" class="form-section">
    <div class="card">
      <h2><span>P</span>ersonal</h2>
      <div class="form-group">
        <input type="text" name="last_name" placeholder="Last Name" required>
        <input type="text" name="first_name" placeholder="First Name" required>
        <div class="inline-group">
          <input type="text" name="middle_initial" placeholder="M.I">
          <input type="text" name="suffix" placeholder="Suffix">
        </div>
      </div>
  
      <div class="form-group">
        <select name="location" required>
          <option disabled selected value="">Select Location</option>
          <?php foreach ($philippines_places as $place) {
            echo "<option>$place</option>";
          } ?>
        </select>
        <select name="gender" required>
          <option disabled selected value="">Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Prefer not to say">Prefer not to say</option>
        </select>
          <input type="number" name="age" placeholder="Age" required>
      </div>
      <div class="form-group">
        <select name="availability" style="flex: 1 1 130px;" required>
          <option disabled selected value="">Availability</option>
          <option value="Weekdays">Weekdays</option>
          <option value="weekends">Weekends</option>
          <option value="Evening">Evenings</option>
        </select>
          <textarea name="bio" class="bio-textarea" placeholder="Write something about yourself and your skills..." style="flex: 1 1 320px; height: 60px; resize: none; border-radius: 15px;" required></textarea>
      </div><br>
    </div>

    <div class="card">
      <h2><span>E</span>ducation</h2>
      <div class="form-group">
        <input type="email" name="plm_email" value="<?php echo $email ?>" readonly required>
        <input type="text" name="college" value="College of Information System & Technology Management" readonly required>
      </div>
      <div class="form-group">
        <select name="course" class="course-select" required>
          <option disabled selected value="">Course</option>
          <option value="Bachelor of Science in Information Technology">Bachelor of Science in Information Technology</option>
          <option value="Bachelor of Science in Computer Science">Bachelor of Science in Computer Science</option>
        </select>
        <select name="status" required>
          <option disabled selected value="">Status</option>
          <option value="Regular">Regular</option>
          <option value="Irregular">Irregular</option>
        </select>
        <select name="year" required>
          <option disabled selected value="">Year</option>
          <option value="1st Year">1st Year</option>
          <option value="2nd Year">2nd Year</option>
          <option value="3rd Year">3rd Year</option>
          <option value="4th Year">4th Year</option>
          <option value="5th Year">5th Year</option>
          <option value="6th Year">6th Year</option>
        </select>
        <select name="block" required>
          <option disabled selected value="">Block</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
        </select>
      </div>
    </div><br>

    <div class="card" id="skills-offer-card">
      <h2><span>S</span>kills Offer</h2>

      <div id="skills-offer-container">
        <div class="form-group skills-offer">
          <select name="category[]" onchange="populateSpecificSkills(this); updateAssessmentButtons();" required>
            <option disabled selected value="">Skill Category</option>
            <option value="Programming">Programming</option>
            <option value="Web Development">Web Development</option>
            <option value="Database">Database</option>
          </select>

          <select name="specific_skill[]" onchange="updateAssessmentButtons();" required>
            <option disabled selected value="">Specific Skill</option>
          </select>

          <!-- Inline individual assessment button area -->
          <div class="assessment-button-container"></div>
        </div>
      </div>

      <div id="main-assessment-btn">
        <button type="submit" id="assessment-btn" class="skills-btn"  name="assessment_redirect" value="1" formaction="initial_assessment.php" disabled>Take Initial Assessment</button>
      </div>

      <div id="add-skill-btn-container">
        <button type="button" id="add-skill-btn" class="add-btn" onclick="addSkillSet()">+</button>
      </div>
    </div>

    <div class="fixed-submit-btn">
      <button type="submit" name="final_submit" class="skills-btn">Submit</button>
    </div>
  </form>
</div>

<script>
  const assessmentResults = <?= json_encode($assessments) ?>;
</script>

<script>
const skillsByCategory = {
  "Programming": ["Python", "Java", "C", "C++", "PHP", "Javascript"],
  "Web Development": ["CSS", "HTML", "Node.js", "React", "Laravel"],
  "Database": ["SQL", "NoSQL", "MongoDB"]
};

// Get all selected specific skills
function getSelectedSkills() {
  return Array.from(document.querySelectorAll('select[name="specific_skill[]"]'))
    .map(select => select.value)
    .filter(value => value);
}

// Populate specific skills dropdown based on category
function populateSpecificSkills(selectElement) {
  const skillSelect = selectElement.parentNode.querySelector('select[name="specific_skill[]"]');
  skillSelect.innerHTML = '<option disabled selected value="">Specific Skill</option>';

  const selectedCategory = selectElement.value;
  let skills = skillsByCategory[selectedCategory] || [];

  skills.forEach(skill => {
    const option = document.createElement('option');
    option.value = skill;
    option.text = skill;
    skillSelect.add(option);
  });

  skillSelect.addEventListener("change", () => updateAssessmentButtons());
  updateAssessmentButtons();
}


// Enable or disable assessment buttons based on selection
function updateAssessmentButtons() {
  const skillGroups = document.querySelectorAll('.skills-offer');
  const mainAssessmentBtnContainer = document.getElementById('main-assessment-btn');

  skillGroups.forEach(group => {
    const category = group.querySelector('select[name="category[]"]').value;
    const skill = group.querySelector('select[name="specific_skill[]"]').value;

    // Remove existing button container if any
    let buttonContainer = group.querySelector('.assessment-button-container');
    if (buttonContainer) buttonContainer.remove();

    // If more than 1 skill group, create inline assessment buttons or proficiency labels
    if (skillGroups.length > 1) {
      buttonContainer = document.createElement('div');
      buttonContainer.className = 'assessment-button-container';
      buttonContainer.style.display = 'flex';
      buttonContainer.style.alignItems = 'center';
      buttonContainer.style.gap = '8px';
      group.appendChild(buttonContainer);

      if (category && skill) {
        if (assessmentResults[category] && assessmentResults[category][skill]) {
          // If already has assessment result — show label only
          const label = document.createElement('span');
          label.textContent = assessmentResults[category][skill];
          label.style.padding = '8px 18px';
          label.style.borderRadius = '6px';
          label.style.backgroundColor = '#007bff';
          label.style.color = '#fff';
          label.style.fontWeight = 'bold';
          buttonContainer.appendChild(label);

          group.querySelector('select[name="category[]"]').disabled = true;
          group.querySelector('select[name="specific_skill[]"]').disabled = true;

        } else {
          // Else — add assessment button with required validation
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'skills-btn individual-assessment-btn';
          btn.textContent = 'Take Initial Assessment';
          
          // ✅ THIS IS THE FIXED HANDLER
          btn.onclick = function () {
            const categorySelect = group.querySelector('select[name="category[]"]');
            const skillSelect = group.querySelector('select[name="specific_skill[]"]');

            const currentCategory = categorySelect.value;
            const currentSkill = skillSelect.value;

            if (!currentCategory || !currentSkill) {
              alert("Please select both a category and a specific skill before taking the assessment.");
              return;
            }

            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'initial_assessment.php';

            const categoryInput = document.createElement('input');
            categoryInput.type = 'hidden';
            categoryInput.name = 'category[]';
            categoryInput.value = currentCategory;

            const skillInput = document.createElement('input');
            skillInput.type = 'hidden';
            skillInput.name = 'specific_skill[]';
            skillInput.value = currentSkill;

            form.appendChild(categoryInput);
            form.appendChild(skillInput);
            document.body.appendChild(form);

            // Disable selects immediately after validation
            categorySelect.disabled = true;
            skillSelect.disabled = true;

            form.submit();
          };
          buttonContainer.appendChild(btn);

          // Remove button
          const removeBtn = document.createElement('button');
          removeBtn.type = 'button';
          removeBtn.innerHTML = '❌';
          removeBtn.style.backgroundColor = 'transparent';
          removeBtn.style.color = '#dc3545';
          removeBtn.style.border = 'none';
          removeBtn.style.fontSize = '20px';
          removeBtn.style.cursor = 'pointer';
          removeBtn.title = 'Remove this skill set';
          removeBtn.onclick = function () {
            group.remove();
            updateAssessmentButtons();
          };
          buttonContainer.appendChild(removeBtn);
        }
      }
    }
  });

  // Toggle main assessment button visibility and state
  if (skillGroups.length === 1) {
    const firstGroup = skillGroups[0];
    const category = firstGroup.querySelector('select[name="category[]"]').value;
    const skill = firstGroup.querySelector('select[name="specific_skill[]"]').value;
    mainAssessmentBtnContainer.style.display = 'block';

    const mainAssessmentBtn = document.getElementById('assessment-btn');

    if (assessmentResults[category] && assessmentResults[category][skill]) {
      mainAssessmentBtn.style.display = 'none';

      let label = mainAssessmentBtnContainer.querySelector('.proficiency-label');
      if (!label) {
        label = document.createElement('span');
        label.className = 'proficiency-label';
        label.style.padding = '8px 18px';
        label.style.borderRadius = '6px';
        label.style.backgroundColor = '#007bff';
        label.style.color = '#fff';
        label.style.fontWeight = 'bold';
        label.style.display = 'inline-block';
        mainAssessmentBtnContainer.appendChild(label);
      }
      label.textContent = assessmentResults[category][skill];

      firstGroup.querySelector('select[name="category[]"]').disabled = true;
      firstGroup.querySelector('select[name="specific_skill[]"]').disabled = true;

    } else {
      mainAssessmentBtn.style.display = 'inline-block';
      mainAssessmentBtn.disabled = !category || !skill;

      const label = mainAssessmentBtnContainer.querySelector('.proficiency-label');
      if (label) label.remove();

      firstGroup.querySelector('select[name="category[]"]').disabled = false;
      firstGroup.querySelector('select[name="specific_skill[]"]').disabled = false;
    }
  } else {
    mainAssessmentBtnContainer.style.display = 'none';
  }
}

// Add a new skill group with category, specific skill, assessment button, and remove button
function addSkillSet() {
  const container = document.getElementById('skills-offer-container');
  const mainAssessmentBtnContainer = document.getElementById('main-assessment-btn');
  mainAssessmentBtnContainer.style.display = 'none';

  const skillGroup = document.createElement('div');
  skillGroup.className = 'form-group skills-offer';

  const categorySelect = document.createElement('select');
  categorySelect.name = 'category[]';
  categorySelect.required = true;
  categorySelect.innerHTML = getCategoryOptions();
  categorySelect.onchange = () => {
    populateSpecificSkills(categorySelect);
    updateAssessmentButtons();
  };

  const specificSkillSelect = document.createElement('select');
  specificSkillSelect.name = 'specific_skill[]';
  specificSkillSelect.required = true;
  specificSkillSelect.innerHTML = '<option disabled selected value="">Specific Skill</option>';
  specificSkillSelect.onchange = updateAssessmentButtons;

  const buttonContainer = document.createElement('div');
  buttonContainer.className = 'assessment-button-container';

  skillGroup.append(categorySelect, specificSkillSelect, buttonContainer);
  container.appendChild(skillGroup);

  updateAssessmentButtons();
}

function getCategoryOptions() {
  return `
    <option disabled selected value="">Skill Category</option>
    <option value="Programming">Programming</option>
    <option value="Web Development">Web Development</option>
    <option value="Database">Database</option>
  `;
}

// Enable submit button if all required fields and assessments are done
function checkIfFormCanBeSubmitted() {
  const form = document.getElementById('profile-setup-form');
  const assessmentBtns = document.querySelectorAll('.individual-assessment-btn, #assessment-btn');
  const disabledSelects = form.querySelectorAll('select[disabled]');
  const totalSkillGroups = document.querySelectorAll('.skills-offer').length;

  // If no pending assessments and all fields valid — enable submit button
  const canSubmit =
    assessmentBtns.length === 0 &&
    form.checkValidity() &&
    disabledSelects.length === totalSkillGroups * 2; // category and specific skill per group

  const submitBtn = document.getElementById('submit-btn');
  submitBtn.disabled = !canSubmit;
}

// Attach validation and submit event
window.onload = () => {
  updateAssessmentButtons();
  checkIfFormCanBeSubmitted();

  const form = document.getElementById('profile-setup-form');

  // Watch changes on selects to reevaluate submit availability
  form.addEventListener('change', () => {
    checkIfFormCanBeSubmitted();
  });

  // On form submission
  form.addEventListener('submit', (e) => {
    if (!form.checkValidity()) {
      e.preventDefault();
      form.reportValidity();
    } else {
      // Disable the submit button to prevent multiple clicks
      document.getElementById('submit-btn').disabled = true;
    }
  });
};

// Initialize on page load
window.onload = () => {
  updateAssessmentButtons();
};
</script>

</body>
</html>

