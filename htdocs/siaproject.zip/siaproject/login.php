<?php
ob_start();
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    unset($_SESSION['email']);
}

$error_msg = $_SESSION['login_error'] ?? '';
$email_error = $_SESSION['email_error'] ?? '';

// Clear messages after displaying
unset($_SESSION['login_error']);
unset($_SESSION['email_error']);
ob_end_flush();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SkillSynergy Log In</title>
  <style>
    body {
      background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      background-image: url('S1.jpg');
      background-repeat: no-repeat;
      background-size: cover;
      margin: 0px;
    }

    ul {
      list-style-type: none;
      margin-left: 1160px;
      padding: 2px;
      overflow: hidden;
      background-color: #333;
      border-radius: 50px;
      margin-top: 90px;
    }

    li {
      float: left;
      border-right: 1px solid #fff;
    }

    li a {
      display: block;
      color: white;
      text-align: center;
      padding: 15px 16px;
      text-decoration: none;
    }

    li:last-child {
      border-right: none;
    }

    li a:hover:not(.active) {
      background-color: #111;
    }

    .active {
      background-color: #04AA6D;
    }

    .login-form {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      width: 350px;
      padding: 30px;
      margin-left: 1100px;
      margin-top: 160px;
    }

    .login-form input[type="text"],
    .login-form input[type="password"] {
      border: 1px solid #ccc;
      outline: none;
      padding: 12px 20px;
      font-size: 16px;
      border-radius: 50px;
      margin-bottom: 20px;
      width: 90%;
      border: 1px solid black;
    }

    .login-form button {
      background-color:rgb(169, 172, 171);
      border: none;
      padding: 12px 20px;
      border-radius: 50px;
      cursor: pointer;
      font-size: 16px;
      color: white;
      width: 60%;
      transition: background-color 0.3s ease;
    }

    .login-form button:hover {
      background-color: #039e62;
    }

    .error-message {
      color: red;
      font-size: 14px;
      margin-top: 10px;
      text-align: center;
    }

    .forgot-password-link {
      font-size: 14px;
      color: #333;
      text-decoration: none;
      margin-bottom: 20px;
      display: inline-block;
      transition: color 0.2s ease;
    }

    .forgot-password-link:hover {
      color: #04AA6D;
      text-decoration: underline;
    }
  </style>
</head>
<body>

<ul>
  <li><a href="signup.php">Sign in</a></li>
  <li><a href="start.php">Home</a></li>
</ul>

<form class="login-form" action="process_login.php" method="POST">
  <input type="text" name="email" id="emailInput" placeholder="Username" required>
  <input type="password" name="password" id="passwordInput" placeholder="Password" required>

  <?php if (!empty($error_msg)) : ?>
    <div class="error-message"><?php echo htmlspecialchars($error_msg); ?></div>
  <?php endif; ?>

  <?php if (!empty($email_error)) : ?>
    <div class="error-message"><?php echo htmlspecialchars($email_error); ?></div>
  <?php endif; ?> <br>

  <button type="submit">Log In</button><br>

  <a href="" class="forgot-password-link">Forgot Password?</a>
</form>

<script>
  // Clear all error messages when typing new email or password
  const emailInput = document.getElementById('emailInput');
  const passwordInput = document.getElementById('passwordInput');

  function clearErrorMessages() {
    const errorMessages = document.querySelectorAll('.error-message');
    errorMessages.forEach(msg => msg.remove());
  }

  emailInput.addEventListener('input', clearErrorMessages);
  passwordInput.addEventListener('input', clearErrorMessages);
</script>

</body>
</html>




