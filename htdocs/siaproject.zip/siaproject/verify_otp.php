<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'sia1');

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$email = $_POST['email'] ?? $_SESSION['email'] ?? '';
$enteredOtp = $_POST['otp'] ?? '';
$correctOtp = $_SESSION['otp'] ?? '';

// Check if OTP is valid and within 5 minutes via DB
$query = $conn->prepare("SELECT * FROM email_verification WHERE email = ? AND otp = ? AND created_at >= (NOW() - INTERVAL 5 MINUTE)");
$query->bind_param("ss", $email, $enteredOtp);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0 && $enteredOtp == $correctOtp) {
    // OTP matched and within time
    $_SESSION['verified_email'] = $email;
    $_SESSION['verified_otp'] = $enteredOtp;
    $_SESSION['otp_valid'] = true;

    header("Location: create_account.php");
    exit;
} else {
    $_SESSION['otp_error'] = "Invalid or expired OTP. Please try again.";
    $_SESSION['otp_valid'] = false;
    header("Location: signup.php");
    exit;
}

$conn->close();
?>









