<?php
session_start();

// Keep email input value if email was sent
$email = $_SESSION['email'] ?? '';

// Check verification status and error messages
$verified = $_SESSION['verified_email'] ?? false;
$error_msg = $_SESSION['otp_error'] ?? '';
$email_error = $_SESSION['email_error'] ?? '';

// Check if OTP has been sent
$otp_sent = $_SESSION['otp_sent'] ?? false;

// Button class & label for Verify button
$btnClass = 'btn-primary';
$btnLabel = 'Verify';

if ($verified) {
    $btnClass = 'btn-success';
    $btnLabel = 'Verified';
} elseif (!empty($error_msg)) {
    $btnClass = 'btn-danger';
    $btnLabel = 'Invalid';
}

// If verified, clear session vars
if ($verified) {
    unset($_SESSION['email']);
    unset($_SESSION['verified_email']);
    unset($_SESSION['otp_sent']);
    unset($_SESSION['otp_error']);
    unset($_SESSION['email_error']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SkillSynergy Sign Up</title>
<style>
body {
    background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
    font-family: 'Segoe UI', sans-serif;
    background-image: url('S.jpg');
    background-repeat: no-repeat;
    background-size: cover;
    margin: 0px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}
form {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 400px;
    background: #fff;
    border-radius: 50px;
    padding: 5px;
    margin-bottom: 5px;
    margin-left: 1050px;
    margin-top: 18px;
    border: 1px solid black;
}
input[type="email"], input[type="text"] {
    border: none;
    outline: none;
    padding: 12px 20px;
    font-size: 16px;
    flex: 1;
    border-radius: 50px;
    margin-right: 10px;
}
/* Base Button Style */
button, .btn {
    border: none;
    padding: 10px 18px;
    border-radius: 50px;
    cursor: pointer;
    font-size: 14px;
    color: white;
    transition: background-color 0.3s ease;
}
/* Variant: Primary */
.btn-primary {
    background-color: rgb(166, 168, 170);
}
/* Variant: Primary Hover */
.btn-primary:hover {
    background-color: rgb(31, 148, 250);
}
/* Variant: Success */
.btn-success {
    background-color: #28a745;
}
/* Variant: Danger */
.btn-danger {
    background-color: #dc3545;
}
.timer {
    font-size: 14px;
    margin-left: 10px;
    color: #333;
    font-weight: bold;
}
.error-message {
    color: red;
    font-size: 13px;
    margin-top: 20px;
    margin-bottom: 10px;
    text-align: left;
    width: 400px;
    margin-left: 1260px;
}
@media (max-width: 450px) {
    form {
        width: 90%;
        flex-direction: column;
    }
    input {
        margin: 10px 0;
    }
    button {
        width: 100%;
    }
}
ul {
    list-style-type: none;
    margin-left: 1160px;
    padding: 2px;
    overflow: hidden;
    background-color: #333;
    border-radius: 50px;
    margin-bottom: 280px;
    margin-top: 70px;
}
li {
    float: left;
}
li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
li a:hover:not(.active) {
    background-color: #111;
}
.active {
    background-color: #04AA6D;
}
</style>
</head>
<body>

<ul>
    <li><a href="Login.php">Log in</a></li>
</ul>

<!-- Email Form -->
<form action="send_otp.php" method="POST">
    <input type="email" id="emailInput" name="email" placeholder="Enter your PLM Email" value="<?php echo htmlspecialchars($email); ?>" required>
    <button type="submit" id="resendButton" class="btn btn-primary">
        <?php echo $otp_sent ? 'Resend OTP' : 'Send OTP'; ?>
    </button>
</form>

<?php if (!empty($email_error)): ?>
    <div class="error-message email-error"><?php echo $email_error; ?></div>
<?php endif; ?>

<!-- OTP Verification Form -->
<form action="verify_otp.php" method="POST" id="otpForm">
    <input type="text" name="otp" id="otpInput" placeholder="One Time Password" required>
    <button type="submit" id="verifyButton" class="<?php echo $btnClass; ?>">
        <?php echo $btnLabel; ?>
    </button>
    <?php if ($otp_sent): ?>
    <span id="timer" class="timer">40s</span>
    <?php endif; ?>
</form>

<?php if (!empty($error_msg)): ?>
    <div class="error-message otp-error"><?php echo $error_msg; ?></div>
<?php endif; ?>

<script>
// Force full reload if navigating back
if (performance.navigation.type === 2) {
  location.reload(true);
}

const verifyButton = document.getElementById('verifyButton');
const otpInput = document.getElementById('otpInput');
const emailInput = document.querySelector('input[name="email"]');  // Correct selector

// Reset Verify button back to primary when typing new OTP (DO NOT touch resend button)
otpInput.addEventListener('input', () => {
  verifyButton.textContent = 'Verify';
  verifyButton.classList.remove('btn-danger', 'btn-secondary');
  verifyButton.classList.add('btn-primary');

  // Clear OTP error message when typing
  const otpError = document.querySelector('.otp-error');
  if (otpError) {
    otpError.remove();
  }
});

// Clear email error message when typing new email
emailInput.addEventListener('input', () => {
  const emailError = document.querySelector('.email-error');
  if (emailError) {
    emailError.remove();
  }
});

// If OTP sent, start countdown timer
<?php if ($otp_sent): ?>
  const resendButton = document.getElementById('resendButton');
  const timerElement = document.getElementById('timer');

  // Disable resend button initially
  resendButton.disabled = true;
  let timeLeft = 40;

  let timer = setInterval(() => {
    timerElement.textContent = `${timeLeft}s`;
    timeLeft--;
    if (timeLeft < 0) {
      clearInterval(timer);
      timerElement.textContent = 'Expired';
      resendButton.disabled = false;
      resendButton.classList.remove('btn-secondary');
      resendButton.classList.add('btn-primary');
    }
  }, 1000);

  // If invalid OTP previously — update verify button only
  <?php if (!empty($error_msg)): ?>
    verifyButton.textContent = 'Invalid';
    verifyButton.classList.remove('btn-primary', 'btn-success');
    verifyButton.classList.add('btn-danger');
  <?php endif; ?>

<?php endif; ?>
</script>

<?php
// Clean session values after load
unset($_SESSION['otp_error']);
unset($_SESSION['email_error']);
?>
</body>
</html>










