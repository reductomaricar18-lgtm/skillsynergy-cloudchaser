  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <title>Document</title>
    <style>
      body {
        min-height: 100vh;
        background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
        background-image: url('S3.jpg');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        background-position: center;
        background-attachment: fixed;
        font-family: 'Segoe UI', sans-serif;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        overflow: hidden;
      }

      .sidebar {
        position: fixed;
        top: 80px;
        left: 75px;
        width: 250px;
        height: 80vh;
        background: rgba(206, 204, 204, 0.7);
        backdrop-filter: blur(10px);
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 20px 0;
        border-radius: 20px;
        box-shadow:
          5px 5px rgba(0, 0, 0, 0.4),
          -3px -5px rgba(255, 255, 255, 0.8);
      }

      .logo img {
        width: 100%;
        height: 120%;
        margin-top: 30px;
        object-fit: cover;
      }

      .sidebar a {
        color: #000;
        font-size: 20px;
        margin: 10px 0px;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 15px;
        padding: 10px 20px;
        width: 200px;
        border-radius: 12px;
        transition: background 0.3s, color 0.3s;
      }

      .sidebar a i {
        font-size: 22px;
      }

      .sidebar a:hover {
        background: #007BFF;
        color: #fff;
      }

      .profile-dropdown {
        position: fixed;
        top: 20px;
        right: 80px;
        text-align: center;
      }

      .profile-container {
        position: relative;
        width: 50px;
        height: 50px;
        cursor: pointer;
      }

      .profile-icon {
        width: 45px;
        height: 45px;
        background: #004466;
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        transition: 0.8s;
      }

      .profile-icon:hover {
        background: #007BFF;
      }

      .arrow-icon {
        position: absolute;
        bottom: 0px;
        right: 0px;
        background-color: rgb(7, 0, 0);
        color: rgb(12, 105, 199);
        border-radius: 50%;
        width: 16px;
        height: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
      }

      .dropdown-content {
        display: none;
        position: absolute;
        right: 0;
        margin-top: 5px;
        background: rgba(218, 214, 214, 0.88);
        min-width: 120px;
        border-radius: 8px;
        overflow: hidden;
        z-index: 1;
        box-shadow:
          5px 5px rgba(0, 0, 0, 0.4),
          -3px -5px rgba(255, 255, 255, 0.8);
      }

      .dropdown-content a {
        padding: 12px 16px;
        display: block;
        text-decoration: none;
        color: #333;
        font-weight: bold;
      }

      .dropdown-content a:hover {
        background-color: #ddd;
      }

      .profile-dropdown:hover .dropdown-content {
        display: block;
      }
      .main-content {
        flex: 1;
        padding: 40px 50px;
        overflow-y: auto;
        width: calc(100% - 320px); 
        margin-left: 320px; 
        margin-top: 40px; 
        box-sizing: border-box;
        display: flex;
        flex-direction: row;
        align-items: flex-start;
      }



      .chat-container {
        flex-direction: column;
        width: 60%;
        height: auto;
        border-radius: 20px;
        overflow: hidden;
        padding: 20px;
        
    
      }

      .message-list {
        width: 40%;
        background: rgba(255, 255, 255, 0.4);
        padding: 20px;
        box-sizing: border-box;
        border-radius: 20px;
        margin-right: 20px;
      

      }

      .message-list h2 {
        text-align: center;
        font-weight: bold;
        margin-bottom: 20px;
      }

      .message-preview {
        display: flex;
        align-items: center;
        background: white;
        margin-bottom: 15px;
        padding: 7px;
        border-radius: 25px;
        cursor: pointer;
        box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
      }

      .message-preview img {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        margin-right: 15px;
      }

      .message-text .name {
        font-weight: bold;
        font-size: 16px;
        margin: 0;
      }

        /* Message Detail View */

      .message-detail {
        width: 55%;
        background: rgba(255, 255, 255, 0.5);
        padding: 20px;
        box-sizing: border-box;
        border-radius: 20px;
        box-shadow: 5px 5px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        gap: 15px;
        visibility: hidden;   
        opacity: 0;
        margin-left; 100px;
        transition: visibility 0s, opacity 0.5s ease-in-out;
      }

      .message-detail.active {
        visibility: visible;
        opacity: 1;
      }

      .message-detail .name {
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 15px;
      }

      .message-detail .chatbox {
        background: #f5f5f5;
        padding: 20px;
        border-radius: 10px;
        height: 300px;
        overflow-y: auto;
      }

      .message-detail .input-box {
        margin-top: 15px;
        display: flex;
        gap: 10px;
      }

      .message-detail .input-box input {
        flex: 1;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #ccc;
      }

      .message-detail .input-box button {
        padding: 10px 15px;
        background: #007BFF;
        color: white;
        border: none;
        border-radius: 5px;
      }

      
    
      .attachment-icon {
        font-size: 20px;
        cursor: pointer;
        background: #007BFF;
        color: white;
        padding: 10px;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative; 
      }

      
      .attachment-dropdown {
        display: none; 
        position: absolute; 
        top: 495px; 
        right:400px;
        transform: translateX(-50%); 
        background: rgba(255, 255, 255, 1);
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
        padding: 10px;
        border-radius: 10px;
        width: 150px;
        z-index: 10; 
      }

      .attachment-dropdown.active {
        display: block;
      }

   
      .attachment-dropdown a {
        display: block;
        padding: 10px;
        text-decoration: none;
        color: #333;
        font-weight: bold;
        border-radius: 5px;
        transition: background-color 0.3s ease;
      }


      .attachment-dropdown a:hover {
        background-color: #f0f0f0;
      }

    .sidebar a.active {
      position: relative;
      font-weight: bold;
      color: #007BFF;
    }

    .sidebar a.active::after {
      content: "";
      position: absolute;
      bottom: 5px;
      left: 20px;
      width: 80%;
      height: 3px;
      background-color: #007BFF;
      border-radius: 5px;
    }

    </style>
  </head>
  <body>

<?php
  $current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
  <div class="logo">
    <img src="logo-profilepage.jpg" alt="Logo">
  </div>
  <br><br><br>

  <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>" title="Home">
    <i class="fas fa-home"></i> Home
  </a>
  
  <a href="findmatch.php" class="<?= $current_page == 'findmatch.php' ? 'active' : '' ?>" title="Find Match">
    <i class="fas fa-search"></i> Find Match
  </a>
  
  <a href="notificationtab.php" class="<?= $current_page == 'notificationtab.php' ? 'active' : '' ?>" title="Notifications">
    <i class="fas fa-bell"></i> Notification
  </a>
  
  <a href="matched_tab.php" class="<?= $current_page == 'matched_tab.php' ? 'active' : '' ?>" title="Matched Users">
    <i class="fas fa-user-friends"></i> Matched
  </a>
  
  <a href="message.php" class="<?= $current_page == 'message.php' ? 'active' : '' ?>" title="Messages">
    <i class="fas fa-comment-dots"></i> Message
  </a>
</div>

    <div class="profile-dropdown">
      <div class="profile-container">
        <div class="profile-icon">
          <i class="fas fa-user"></i>
        </div>
        <div class="arrow-icon"><i class="fas fa-caret-down"></i></div>
      </div>
      <div class="dropdown-content">
        <a href="user_profile.php">Profile</a>
        <a href="logout.php">Log Out</a>
      </div>
    </div>

  <div class="main-content">
   
      <div class="message-list">
        <h2>Messages</h2>
        <div class="message-preview" onclick="showMessageDetail('Ralph Aeron Estanislao', 'Some information about Ralph')">
          <img src="profile.jpg" alt="Profile">
          <div class="name">Ralph Aeron Estanislao</div>
        </div>
          <div class="message-preview" onclick="showMessageDetail('Aldrin', 'Some information about Aldrin')">
          <img src="profile.jpg" alt="Profile">
          <div class="name">Aldrin Manay</div>
        </div>
        <div class="message-preview" onclick="showMessageDetail('Maricar Reducto', 'Some information about Maricar')">
          <img src="profile.jpg" alt="Profile">
          <div class="name">Maricar Reducto</div>
        </div>
      </div>
          

    <div class="message-detail" id="messageDetail">
        <div class="name" id="detailName">RALPH AERON H. ESTANISLAO</div>
        <p id="detailInfo">Some information about Ralph</p>
        <div class="chatbox">
        
        </div>
        <div class="input-box">

        <div class="attachment-icon" onclick="toggleAttachmentDropdown()">
            <i class="fas fa-paperclip"></i>
          </div>

          
          <div class="attachment-dropdown" id="attachmentDropdown">
            <input type="file" id="fileInput" style="display: none;" onchange="handleFileSelect(event)" />
            
            <a href="#" onclick="triggerFileInput()">Send File</a>
            <a href="#">End Session</a>
          </div>


          <input type="text" placeholder="Type a message..." />
          <button>Send</button>
        </div>
      </div>
    </div>

    <script>
    

      function toggleAttachmentDropdown() {
        const dropdown = document.getElementById('attachmentDropdown');
        dropdown.classList.toggle('active');
      }

      // Trigger file input when "Send File" is clicked
      function triggerFileInput() {
        document.getElementById('fileInput').click();
      }

      function showMessageDetail(name, info) {
        
        document.getElementById('detailName').innerText = name;
        document.getElementById('detailInfo').innerText = info;

        //message detail panel
        const messageDetail = document.getElementById('messageDetail');
        messageDetail.classList.add('active');
      }
    </script>
    
  
  </body>
  </html>
