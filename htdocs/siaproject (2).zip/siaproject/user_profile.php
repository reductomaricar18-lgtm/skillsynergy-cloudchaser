<?php
session_start();

// Make sure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user profile (except profile_pic — we'll use function for that)
$sql = "SELECT last_name, first_name, middle_initial, suffix, age, gender, location, availability, bio FROM users_profile WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$profile = $result->fetch_assoc();
$stmt->close();

// Save profile fields to session (except profile_pic)
if ($profile) {
    $_SESSION['age'] = $profile['age'];
    $_SESSION['gender'] = $profile['gender'];
    $_SESSION['location'] = $profile['location'];
    $_SESSION['availability'] = $profile['availability'];
    $_SESSION['bio'] = $profile['bio'];
}

// Fetch education
$sql = "SELECT course, year, block, status FROM education WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$education = $result->fetch_assoc();
$stmt->close();

if ($education) {
    $_SESSION['course'] = $education['course'];
    $_SESSION['year'] = $education['year'];
    $_SESSION['block'] = $education['block'];
    $_SESSION['status'] = $education['status'];
}

// Fetch skills
$stmt = $conn->prepare("SELECT skills_id, category, specific_skill FROM skills_offer WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$skills_result = $stmt->get_result();
$skills = $skills_result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch initial_assessment
$stmt = $conn->prepare("SELECT skills_id, proficiency FROM initial_assessment WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$assessment_result = $stmt->get_result();
$assessments = $assessment_result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$proficiencyMap = [];
foreach ($assessments as $row) {
    $proficiencyMap[$row['skills_id']] = $row['proficiency'];
}

foreach ($skills as $skill) {
    $skill_id = $skill['skills_id'];
    $skill_name = $skill['specific_skill'];
    
    // check if assessment exists
    $proficiency = isset($proficiencyMap[$skill_id]) ? $proficiencyMap[$skill_id] : 'Not Assessed';
}

// Always fetch latest profile picture from DB (no session storage)
$profilePicPath = getProfilePic($conn, $user_id);

// Function to fetch profile picture
function getProfilePic($conn, $user_id) {
    $stmt = $conn->prepare("SELECT profile_pic FROM users_profile WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($fetched_pic);
    $pic = 'uploads/default.jpg';
    if ($stmt->fetch() && !empty($fetched_pic)) {
        $pic = $fetched_pic;
    }
    $stmt->close();
    return $pic;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SkillSynergy Profile Page</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
   * {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  min-height: 100vh;
  background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
  background-image: url('S3.jpg');
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: center;
  font-family: 'Segoe UI', sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
}

.sidebar {
  position: fixed;
  top: 100px;
  left: 75px;
  width: 120px;
  height: 80vh;
  background: rgba(206, 204, 204, 0.7);
  backdrop-filter: blur(10px);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
  border-radius: 20px;
  box-shadow: 5px 5px rgba(0, 0, 0, 0.4),
              -3px -5px rgba(255, 255, 255, 0.8);
}

.logo img {
  width: 100%;
  height: 100%;
  margin-top: 20px;
  object-fit: cover;
}

.sidebar a {
  color: #000;
  font-size: 30px;
  margin: 10px 0;
  text-decoration: none;
  transition: 0.8s;
}

.sidebar a:hover {
  color: #007BFF;
}

.main-content {
  margin-left: 100px;
  padding: 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
  margin-top: 10px;
}

.profile-section {
  display: flex;
  align-items: flex-start;
  gap: 40px;
}

.profile-pic-container {
  position: relative;
  width: 300px;
  height: 300px;
}

.profile-pic-container img {
  width: 300px;
  height: 300px;
  border-radius: 50%;
  object-fit: cover;
  border: 3px solid #004466;
}

.upload-btn {
  position: absolute;
  bottom: 10px;
  right: 20px;
  background: #007BFF;
  color: #fff;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
}

.details {
  flex: 1;
  background: rgba(255, 255, 255, 0.25);
  padding: 8px;
  border-radius: 16px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.18);
  gap: 10px;
}

.details h3 {
  font-size: 30px;
  margin-bottom: 40px;
}

.details p {
  margin: 5px 0;
  font-size: 16px;
}

.bio-box {
  background: rgba(255, 255, 255, 0.25);
  padding: 10px;
  border-radius: 16px;
  margin-left: 340px;
  max-width: 820px;
  width: 100%;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.18);
  display: flex;
  gap: 8px;
}

.bio-box h3 {
  color: #004466;
}

.matches-box {
  background: rgba(255, 255, 255, 0.25);
  padding: 30px;
  border-radius: 16px;
  margin: 10px auto;
  max-width: 1200px;
  width: 100%;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.18);
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.info h3, .matches-box h3, .details h3 {
  margin-bottom: 20px;
  color: #004466;
}

.match-item {
  background: #e8f0fe;
  padding: 12px;
  border-radius: 10px;
  flex: 1 1 calc(50% - 10px);
  display: flex;
  flex-direction: column;
}

.match-item p {
  margin: 5px 0;
  font-size: 14px;
}

.info {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.info-row {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.info-row p {
  margin: 0;
  font-size: 16px;
  flex: 1 1 10%;
  min-width: 100px;
}

.matches-header {
  display: flex;
  align-items: center;
  gap: 420px;
  margin-bottom: 2px;
  flex-wrap: wrap;
}

.matches-header p {
  margin-left: 10px;
  color: #004466;
  font-size: 20px;
}

.matches-details {
  display: flex;
  flex-wrap: wrap;
  gap: 40px;
  align-items: flex-start;
}

.row {
  background: rgba(255, 255, 255, 0.25);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 16px;
  padding: 10px;
  flex: 0 0 calc(50% - 20px); /* 50% width minus gap */
  height: 150px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(12px);
  display: flex;
  justify-content: space-between;
  position: relative;
}

.comment-box {
  background: rgba(255, 255, 255, 0.25);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 16px;
  padding: 10px;
  flex: 0 0 calc(50% - 20px); /* 50% width minus gap */
  height: 150px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(12px);
  display: flex;
  justify-content: space-between;
  position: relative;
}

/* Specific tweaks for .row content */
.row p {
  display: flex;
  flex-direction: column;
  margin-right: 25px;
  font-size: 16px;
  color: #333;
}

.row p strong {
  font-weight: bold;
  margin-bottom: 5px;
  color: #222;
}

/* Comment box scrollable content */
.comment-box {
  background: #f5f5f5;
  overflow-y: auto;
}

.comment-box p {
  margin: 0;
  font-size: 14px;
  color: #444;
}

/* Custom scrollbar styling */
.comment-box::-webkit-scrollbar {
  width: 6px;
}

.comment-box::-webkit-scrollbar-thumb {
  background: #bbb;
  border-radius: 3px;
}

.comment-box::-webkit-scrollbar-track {
  background: #eee;
}

/* Plus button styling inside .row */
.plus-button {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background:rgb(165, 168, 165);
  color: white;
  border: none;
  border-radius: 50%;
  width: 32px;
  height: 32px;
  font-size: 20px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.3s ease;
}

.plus-button:hover {
  background: #43a047;
}

.info-box {
  background: rgba(255, 255, 255, 0.4);
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 12px;
  padding: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  backdrop-filter: blur(8px);
}

.info-bio {
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.4);
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 12px;
  padding: 6px 14px;
  margin-bottom: 5px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  backdrop-filter: blur(8px);
  font-size: 14px;
  min-height: unset;
  line-height: 1.3;
  width: 800px;
}
  </style>
</head>
<body>

  <div class="sidebar">
    <div class="logo">
      <img src="logo-profilepage.jpg" alt="Logo">
    </div>
    <br><br>
    <a href="dashboard.php" title="Home"><i class="fas fa-home"></i></a>
    <a href="findmatch.php" title="Search"><i class="fas fa-search"></i></a>
    <a href="notificationtab.php" title="Notifications"><i class="fas fa-bell"></i></a>
    <a href="matched_tab.php" title="Matched Users"><i class="fas fa-user-friends"></i></a>
    <a href="message.php" title="Messages"><i class="fas fa-comment-dots"></i></a>

  <a href="profile_page.php" class="back-btn" title="Back">
    <i class="fas fa-arrow-left"></i>
  </a>
  </div>


<!-- Profile Page Form -->
<form method="POST" enctype="multipart/form-data" action="personal_info.php" class="main-content">
<div class="main-content">

  <!-- Profile Section -->
<form action="personal_info.php" method="POST" enctype="multipart/form-data">
  <div class="profile-section">
    <div class="profile-pic-container">
        <img src="<?php echo $profilePicPath; ?>" alt="">
        <label for="profile_pic" class="upload-btn"><i class="fas fa-camera"></i></label>
        <input type="file" id="profile_pic" name="profile_pic" style="display: none;" onchange="this.form.submit()">
    </div>
</form>

    <div class="details">
      <h3><?php echo htmlspecialchars($profile['first_name'] . ' ' . $profile['last_name']); ?></h3>
      <div class="info">
        <div class="info-row">
          <p class="info-box"><strong>Age:</strong> <?php echo !empty($_SESSION['age']) ? htmlspecialchars($_SESSION['age']) : ''; ?></p>
          <p class="info-box"><strong>Gender:</strong> <?php echo !empty($_SESSION['gender']) ? htmlspecialchars($_SESSION['gender']) : ''; ?></p>
          <p class="info-box"><strong>Location:</strong> <?php echo !empty($_SESSION['location']) ? htmlspecialchars($_SESSION['location']) : ''; ?></p>
        </div>
        <div class="info-row">
          <p class="info-box"><strong>Availability:</strong> <?php echo !empty($_SESSION['availability']) ? htmlspecialchars($_SESSION['availability']) : ''; ?></p>
          <p class="info-box"><strong>PLM Email:</strong> <?php echo !empty($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : ''; ?></p>
        </div>
        <div class="info-row">
          <p class="info-box"><strong>Course:</strong> <?php echo !empty($_SESSION['course']) ? htmlspecialchars($_SESSION['course']) : ''; ?></p>
          <p class="info-box"><strong>Year:</strong> <?php echo !empty($_SESSION['year']) ? htmlspecialchars($_SESSION['year']) : ''; ?></p>
          <p class="info-box"><strong>Block:</strong> <?php echo !empty($_SESSION['block']) ? htmlspecialchars($_SESSION['block']) : ''; ?></p>
          <p class="info-box"><strong>Status:</strong> <?php echo !empty($_SESSION['status']) ? htmlspecialchars($_SESSION['status']) : ''; ?></p>
        </div>
      </div>
    </div>
  </div>

  <!-- Bio Section -->
  <div class="bio-box">
    <h3>Bio</h3>
    <p class="info-bio"><?php echo !empty($_SESSION['bio']) ? htmlspecialchars($_SESSION['bio']) : 'No bio yet.'; ?></p>
  </div>

  <!-- Skills and Matches Section -->
  <div class="matches-box">
    <div class="matches-header">
      <p><strong>Total Matches:</strong> <?php echo !empty($_SESSION['total_matches']) ? htmlspecialchars($_SESSION['total_matches']) : ''; ?></p>
      <p><strong>Ratings:</strong> <?php echo !empty($_SESSION['ratings']) ? htmlspecialchars($_SESSION['ratings']) : ''; ?></p>
    </div>

  <?php if (!empty($skills)) : ?>
  <?php foreach ($skills as $skill) : ?>
    <div class="matches-details">
      <div class="row">
        <p><strong>Skill/s:</strong> <?php echo htmlspecialchars($skill['specific_skill']); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($proficiency); ?></p>
        <p><strong>Rank:</strong></p>
        
        <button class="plus-button">+</button>
      </div>

      <div class="comment-box">
        <?php
        if (!empty($comments[$skill['skills_id']])) {
          foreach ($comments[$skill['skills_id']] as $comment_text) {
            echo "<p>" . htmlspecialchars($comment_text) . "</p>";
          }
        } else {
          echo "<p>No comments yet.</p>";
        }
        ?>
      </div>
    </div>
  <?php endforeach; ?>
<?php else : ?>
  <p>No skills offered yet.</p>
<?php endif; ?>

</div>
</form>

<script>
  document.getElementById('profile_pic').addEventListener('change', function() {
    const file = this.files[0];
    if (file) {
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        alert("Invalid file type. Please select an image file.");
        this.value = ''; // reset input
      } else if (file.size > 2 * 1024 * 1024) { // 2MB limit
        alert("File is too large. Please select a file under 2MB.");
        this.value = '';
      }
    }
  });
</script>


</body>
</html>


