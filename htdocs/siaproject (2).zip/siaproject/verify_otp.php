<?php
session_start();
$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'] ?? '';
$enteredOtp = $_POST['otp'] ?? '';
$correctOtp = $_SESSION['otp'] ?? '';

// Validate via database within 5 mins
$query = $conn->prepare("SELECT * FROM email_verification WHERE email = ? AND otp = ? AND created_at >= (NOW() - INTERVAL 5 MINUTE)");
$query->bind_param("ss", $email, $enteredOtp);
$query->execute();
$result = $query->get_result();

if ($result->num_rows > 0 && $enteredOtp == $correctOtp) {
    // Valid match
    $_SESSION['verified_email'] = $email;
    $_SESSION['verified_otp'] = $enteredOtp;
    $_SESSION['otp_valid'] = true;

    // ✅ Clear OTP session data now that it's verified
    unset($_SESSION['otp']);
    unset($_SESSION['otp_sent']);

    header("Location: create_account.php");
    exit();
} else {
    // Invalid — set error and unset timer
    $_SESSION['otp_error'] = "Invalid or expired OTP. Please try again.";
    $_SESSION['otp_valid'] = false;

    // ✅ Important: allow resend immediately by removing otp_sent timestamp
    unset($_SESSION['otp_sent']);

    header("Location: signup.php");
    exit();
}

$conn->close();
?>
