<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

// DB Connection
$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Fetch user_id
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($user_id);
if (!$stmt->fetch()) {
    $stmt->close();
    $conn->close();
    header("Location: login.php");
    exit();
}
$stmt->close();

// If the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize form inputs
    $first_name = $conn->real_escape_string($_POST['first_name']);
    $last_name = $conn->real_escape_string($_POST['last_name']);
    $personal_email = $conn->real_escape_string($_POST['personal_email']);
    $contact_number = $conn->real_escape_string($_POST['contact_number']);
    $location = $conn->real_escape_string($_POST['location']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $age = (int)$_POST['age'];
    $availability = $conn->real_escape_string($_POST['availability']);
    $bio = $conn->real_escape_string($_POST['bio']);
    $college = $conn->real_escape_string($_POST['college']);
    $course = $conn->real_escape_string($_POST['course']);
    $status = $conn->real_escape_string($_POST['status']);
    $year = $conn->real_escape_string($_POST['year']);
    $block = $conn->real_escape_string($_POST['block']);

    // Update users_profile table
    $update_query = "UPDATE users_profile 
                     SET first_name = '$first_name', last_name = '$last_name',
                         personal_email = '$personal_email', contact_number = '$contact_number', 
                         location = '$location', gender = '$gender', age = $age,
                         availability = '$availability', bio = '$bio', 
                         college = '$college', course = '$course', 
                         status = '$status', year = '$year', block = '$block' 
                     WHERE user_id = $user_id";

    if ($conn->query($update_query) === TRUE) {
        // If assessment redirect triggered
        if (isset($_POST['assessment_redirect'])) {
            $_SESSION['profile-setup-form'] = $_POST;
            header("Location: initial_assessment.php");
            exit();
        }

        // Mark profile as completed
        $complete_query = "UPDATE users SET profile_completed = 1 WHERE user_id = $user_id";
        if ($conn->query($complete_query) === TRUE) {
            $_SESSION['profile_completed'] = 1;
            unset($_SESSION['profile-setup-form']);
            header("Location: dashboard.php");
            exit();
        }
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}

// ✅ Fetch existing skills_offer for this user
$skills_offered = [];
$result = $conn->query("SELECT category, skill FROM initial_assessment WHERE user_id = $user_id");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $skills_offered[] = $row;
    }
}

// ✅ Fetch assessment results for this user
$assessments = [];
$result = $conn->query("SELECT category, skill, proficiency FROM initial_assessment WHERE user_id = $user_id");
while ($row = $result->fetch_assoc()) {
    $assessments[$row['category']][$row['skill']] = $row['proficiency'];
}

// Philippine places for dropdown
$philippines_places = [
    "Manila", "Quezon City", "Caloocan", "Pasig", "Makati", "Taguig", "Pasay", "Parañaque",
    "Las Piñas", "San Juan", "Mandaluyong", "Marikina", "Muntinlupa", "Navotas", "Valenzuela"
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SkillSynergy Profile Set-up</title>
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
    }

    body {
      background: url('S2.jpg') no-repeat center center fixed;
      background-size: cover;
    }

    .container {
      max-width: 900px;
      margin: 20px 0 20px auto;
      display: flex;
      align-items: flex-start;
      justify-content: flex-end;
      padding-right: 35px;
      padding-top: 90px;
    }

    .form-section {
      background: rgba(255, 243, 243, 0.35);
      border-radius: 18px;
      padding: 13px;
      width: 830px;
      box-shadow: 0 3px 14px rgba(0, 0, 0, 0.25);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.25);
    }

    .card {
      background: rgba(255, 243, 243, 0.35);
      border-radius: 18px;
      padding: 3px 3px;
      margin-bottom: 16px;
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
    }

    .card h2 {
      font-size: 22px;
      margin-bottom: 14px;
      border-bottom: 2px solid #007acc;
      display: inline-block;
      padding-bottom: 4px;
    }

    .card h2 span {
      color: #007acc;
      font-size: 26px;
    }

    .form-group {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 12px;
    }

    .form-group input,
    .form-group select,
    .form-group textarea {
      flex: 1 1 130px;
      padding: 8px 14px;
      border-radius: 18px;
      border: 1px solid #ccc;
      font-size: 14px;
      color: #666;
    }

    .form-group select option:first-child {
      color: #999;
    }

    .form-group textarea {
      flex: 1 1 100%;
      resize: none;
      height: 60px;
      border-radius: 15px;
    }

    .inline-group {
      display: flex;
      gap: 10px;
      flex: 1 1 130px;
    }

    .inline-group input {
      padding: 8px 14px;
      border-radius: 18px;
      border: 1px solid #ccc;
      font-size: 14px;
    }

    .submit-btn, .skills-btn, .add-btn {
      border: none;
      border-radius: 25px;
      font-size: 14px;
      cursor: pointer;
      transition: 0.3s ease;
    }

    .submit-btn {
      background-color: #bbb;
      color: #fff;
      padding: 10px 28px;
      display: block;
      margin: 12px auto 0;
    }

    .submit-btn:hover {
      background-color: #999;
    }

    .skills-btn {
      padding: 8px 16px;
      background-color: #28a745;
      color: #fff;
      border: none;
      border-radius: 6px;
      font-weight: 500;
      cursor: pointer;
      text-align: center;
      transition: background 0.3s ease;
    }

    .skills-btn:hover {
      background-color: #005f9e;
    }

    .fixed-submit-btn {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 20px;
    }

    .fixed-submit-btn #form-error-message {
      color: #dc3545;
      font-weight: bold;
      margin-top: 10px;
      text-align: center;
    }

    .add-btn:hover {
      background-color: #3e8e41;
    }

    .age-select {
      flex: 1 1 130px;
      padding: 8px 14px;
      border-radius: 18px;
      border: 1px solid #ccc;
      font-size: 14px;
      color: #666;
    }

    .add-btn {
      width: 40px;
      height: 40px;
      background-color: #bdc3c7;
      color: #2c3e50;
      border: none;
      border-radius: 50%;
      font-size: 20px;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: 12px;
    }

    .add-btn:hover {
      background-color: #95a5a6;
    }

    .add-btn:active {
      background-color: #7f8c8d;
      transform: scale(0.95);
    }

    .add-btn:disabled {
      background-color: #ecf0f1;
      color: #bdc3c7;
      cursor: not-allowed;
    }

    .skills-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 8px;
      position: relative;
    }

    .bio-textarea {
      flex: 1 1 320px;
      padding: 8px 14px;
      border-radius: 15px;
      border: 1px solid #ccc;
      font-size: 14px;
      color: #666;
      height: 60px;
      resize: none;
    }

    .bio-textarea:valid,
    .form-group input {
      color: #000;
    }

    select {
      color: #999;
    }

    /* Turn select text black after selecting a valid option */
    select:valid {
      color: #000;
    }

    button.removeSkill {
      margin-left: 10px;
      color: white;
      background: red;
      border: none;
      padding: 5px 10px;
      cursor: pointer;
      border-radius: 5px;
    }

    .assessment-button-container span {
      display: inline-block;
      margin-top: 10px;
    }

    #main-assessment-btn {
      justify-content: center !important;
      margin-top: 15px;
    }
    #assessment-btn {
      display: inline-block; /* or block */
    }

    /* Proficiency badge style */
    .proficiency-label {
      display: inline-block;
      padding: 8px 16px;
      background-color: #007bff;
      color: #fff;
      font-weight: 600;
      border-radius: 8px;
      font-size: 14px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
    }

    /* Badge hover effect */
    .proficiency-label:hover {
      background-color: #0056b3;
      cursor: default;
    }

    .assessment-button-container {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .remove-btn {
      background: transparent;
      border: none;
      color: #dc3545;
      font-size: 20px;
      cursor: pointer;
      padding: 4px 8px;
      transition: color 0.2s ease;
    }

    .remove-btn:hover {
      color: #a71d2a;
    }

    /* Proficiency result badge when assessment done */
    .badge {
      display: inline-block;
      padding: 6px 14px;
      font-size: 13px;
      font-weight: 600;
      border-radius: 50px;
      color: #fff;
      background-color: #007bff;
    }

    /* Result badge specific style */
    .badge-primary {
      background-color: #007bff;
    }

    /* Disable select appearance */
    .skills-offer select:disabled {
      background-color: #e9ecef;
      cursor: not-allowed;
      opacity: 0.9;
    }

    /* Smooth fade-in animation for adding skill set */
    .skills-offer {
      opacity: 0;
      transform: translateY(10px);
      animation: fadeIn 0.4s ease forwards;
    }

    @keyframes fadeIn {
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

  </style>
</head>
<body>

<div class="container">
  <form id="profile-setup-form" action="save_profile.php" method="POST" class="form-section">
    <div class="card">
      <h2><span>P</span>ersonal</h2>
      <div class="form-group">
        <input type="text" name="last_name" placeholder="Last Name" required value="<?= htmlspecialchars($profile['last_name'] ?? '') ?>">
        <input type="text" name="first_name" placeholder="First Name" required value="<?= htmlspecialchars($profile['first_name'] ?? '') ?>">
        <div class="inline-group">
          <input type="text" name="middle_initial" placeholder="M.I" value="<?= htmlspecialchars($profile['middle_initial'] ?? '') ?>">
          <input type="text" name="suffix" placeholder="Suffix" value="<?= htmlspecialchars($profile['suffix'] ?? '') ?>">
        </div>
      </div>
  
      <div class="form-group">
        <select name="location" required>
          <option disabled <?= empty($profile['location']) ? 'selected' : '' ?> value="">Select Location</option>
          <?php foreach ($philippines_places as $place): ?>
            <option value="<?= $place ?>" <?= ($profile['location'] ?? '') === $place ? 'selected' : '' ?>>
              <?= $place ?>
            </option>
          <?php endforeach; ?>
        </select>
        <select name="gender" required>
          <option disabled <?= empty($profile['gender']) ? 'selected' : '' ?> value="">Gender</option>
          <option value="Male" <?= ($profile['gender'] ?? '') === 'Male' ? 'selected' : '' ?>>Male</option>
          <option value="Female" <?= ($profile['gender'] ?? '') === 'Female' ? 'selected' : '' ?>>Female</option>
          <option value="Prefer not to say" <?= ($profile['gender'] ?? '') === 'Prefer not to say' ? 'selected' : '' ?>>Prefer not to say</option>
        </select>
          <input type="number" name="age" placeholder="Age" required value="<?= htmlspecialchars($profile['age'] ?? '') ?>">
      </div>
      <div class="form-group">
        <select name="availability" required>
          <option disabled <?= empty($profile['availability']) ? 'selected' : '' ?> value="">Availability</option>
          <option value="Weekdays" <?= ($profile['availability'] ?? '') === 'Weekdays' ? 'selected' : '' ?>>Weekdays</option>
          <option value="weekends" <?= ($profile['availability'] ?? '') === 'weekends' ? 'selected' : '' ?>>Weekends</option>
          <option value="Evening" <?= ($profile['availability'] ?? '') === 'Evening' ? 'selected' : '' ?>>Evenings</option>
        </select>
          <textarea name="bio" class="bio-textarea" placeholder="Write something about yourself and your skills..." style="flex: 1 1 320px; height: 60px; resize: none; border-radius: 15px;" required><?= htmlspecialchars($profile['bio'] ?? '') ?></textarea>
      </div><br>
    </div>

    <div class="card">
      <h2><span>E</span>ducation</h2>
      <div class="form-group">
        <input type="email" name="plm_email" value="<?php echo $email ?>" readonly required>
        <input type="text" name="college" value="<?= htmlspecialchars($education['college'] ?? 'College of Information System & Technology Management') ?>" readonly required>
      </div>
      <div class="form-group">
        <select name="course" class="course-select" required>
          <option disabled <?= empty($profile['course']) ? 'selected' : '' ?> value="">Course</option>
          <option value="Bachelor of Science in Information Technology" <?= ($education['course'] ?? '') === 'Bachelor of Science in Information Technology' ? 'selected' : '' ?>>Bachelor of Science in Information Technology</option>
          <option value="Bachelor of Science in Computer Science" <?= ($education['course'] ?? '') === 'Bachelor of Science in Computer Science' ? 'selected' : '' ?>>Bachelor of Science in Computer Science</option>
        </select>
        <select name="status" required>
            <option disabled <?= empty($profile['status']) ? 'selected' : '' ?> value="">Status</option>
            <option value="Regular" <?= ($education['status'] ?? '') === 'Regular' ? 'selected' : '' ?>>Regular</option>
            <option value="Irregular" <?= ($education['status'] ?? '') === 'Irregular' ? 'selected' : '' ?>>Irregular</option> 
        </select>
        <select name="year" required>
          <option disabled <?= empty($profile['year']) ? 'selected' : '' ?> value="">Year</option>
          <?php
            $years = ['1st Year', '2nd Year', '3rd Year', '4th Year', '5th Year', '6th Year'];
            foreach ($years as $y) {
              $selected = ($education['year'] ?? '') === $y ? 'selected' : '';
              echo "<option value=\"$y\" $selected>$y</option>";
            }
          ?>
        </select>

        <select name="block" required>
          <option disabled <?= empty($profile['block']) ? 'selected' : '' ?> value="">Block</option>
          <?php
            for ($i = 1; $i <= 6; $i++) {
              $selected = ($education['block'] ?? '') == $i ? 'selected' : '';
              echo "<option value=\"$i\" $selected>$i</option>";
            }
          ?>
        </select>
      </div>
    </div><br>

    <div class="card" id="skills-offer-card">
      <h2><span>S</span>kills Offer</h2>

      <div id="skills-offer-container">
        <div class="form-group skills-offer" id="primary-skill-group">
          <select name="category[]" id="primary-category" onchange="populateSpecificSkills(this); updateAssessmentButtons();" required>
            <option disabled selected value="">Skill Category</option>
            <option value="Programming">Programming</option>
            <option value="Web Development">Web Development</option>
            <option value="Database">Database</option>
          </select>

          <select name="specific_skill[]" id="primary-skill" onchange="updateAssessmentButtons();" required>
            <option disabled selected value="">Specific Skill</option>
          </select>

          <!-- Inline individual assessment button area -->
          <div class="assessment-button-container"></div>
        </div>
      </div>

      <div id="main-assessment-btn">
        <button type="submit" id="assessment-btn" class="skills-btn"  name="assessment_redirect" value="1" formaction="initial_assessment.php" disabled>Take Initial Assessment</button>
      </div>

      <div id="add-skill-btn-container">
        <button type="button" id="add-skill-btn" class="add-btn" onclick="addSkillSet()">+</button>
      </div>
    </div>

  <div class="fixed-submit-btn">
    <button id="submit-btn" type="submit" name="final_submit" class="skills-btn">Submit</button>
    <div id="form-error-message" style="color: #dc3545; font-weight: bold; margin-top: 10px; text-align: center;"></div>
  </div>
  </form>
</div>


<script>
const skillsByCategory = {
  "Programming": ["Python", "Java", "C", "C++", "PHP", "Javascript"],
  "Web Development": ["CSS", "HTML", "Node.js", "React", "Laravel"],
  "Database": ["SQL", "NoSQL", "MongoDB"]
};

const assessmentResults = <?= json_encode($assessments) ?>;
const skillsOffered = <?= json_encode($skills_offered) ?>;

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('profile-setup-form');
  const errorContainer = document.getElementById('form-error-message');
  const skillsContainer = document.getElementById('skills-offer-container');
  const submitBtn = document.getElementById('submit-btn');

  // ✅ Clear localStorage if ?success=1 in URL
  if (window.location.search.includes("success=1")) {
    localStorage.clear();
  }

  // Load stored form data
  form.querySelectorAll('input, select, textarea').forEach(input => {
    const value = localStorage.getItem(input.name);
    if (value !== null) input.value = value;
    input.addEventListener('change', () => localStorage.setItem(input.name, input.value));
  });

  const savedSkills = JSON.parse(localStorage.getItem('skills-offer-data') || "[]");
  skillsContainer.innerHTML = "";
  if (savedSkills.length) {
    savedSkills.forEach(({ category, skill }, index) => addSkillSet(category, skill, index === 0));
  } else {
    addSkillSet("", "", true);
  }

  form.addEventListener('submit', (e) => {
    errorContainer.textContent = "";

    const pendingAssessments = document.querySelectorAll('.individual-assessment-btn, #assessment-btn:not([disabled])').length;
    const skillGroups = document.querySelectorAll('.skills-offer');

    let missingAssessment = false;

    skillGroups.forEach(group => {
      const category = group.querySelector('select[name="category[]"]').value;
      const skill = group.querySelector('select[name="specific_skill[]"]').value;
      if (category && skill) {
        if (!assessmentResults[category] || !assessmentResults[category][skill]) {
          missingAssessment = true;
        }
      }
    });

    if (pendingAssessments > 0 || missingAssessment) {
      e.preventDefault();
      errorContainer.textContent = "⚠️ Please complete the initial assessments for all selected skills before submitting your profile.";
      return;
    }

    const requiredFields = form.querySelectorAll('input[required], select[required], textarea[required]');
    let incompleteFields = false;

    requiredFields.forEach(field => {
      if (!field.disabled && !field.value.trim()) {
        incompleteFields = true;
      }
    });

    if (incompleteFields) {
      e.preventDefault();
      form.reportValidity();
      return;
    }

    // ✅ Clear all localStorage values before actual submission
    localStorage.removeItem('skills-offer-data');
    form.querySelectorAll('input, select, textarea').forEach(input => {
      localStorage.removeItem(input.name);
    });
  });
});

// Add a skill set
function addSkillSet(selectedCategory = "", selectedSkill = "", isPrimary = false) {
  const container = document.getElementById('skills-offer-container');
  const group = document.createElement('div');
  group.className = 'form-group skills-offer';

  const categorySel = document.createElement('select');
  categorySel.name = 'category[]';
  categorySel.required = true;
  categorySel.innerHTML = `<option disabled selected value="">Skill Category</option>` + 
    Object.keys(skillsByCategory).map(cat => `<option value="${cat}">${cat}</option>`).join("");
  if (selectedCategory) categorySel.value = selectedCategory;

  const skillSel = document.createElement('select');
  skillSel.name = 'specific_skill[]';
  skillSel.required = true;
  skillSel.innerHTML = `<option disabled selected value="">Specific Skill</option>`;
  if (selectedCategory) populateSpecificSkills(categorySel, skillSel, selectedSkill);

  categorySel.addEventListener('change', () => {
    populateSpecificSkills(categorySel, skillSel);
    saveSkillsToStorage();
    updateAssessmentButtons();
    checkIfFormCanBeSubmitted();
  });

  skillSel.addEventListener('change', () => {
    saveSkillsToStorage();
    updateAssessmentButtons();
    checkIfFormCanBeSubmitted();
  });

  const buttonContainer = document.createElement('div');
  buttonContainer.className = 'assessment-button-container';
  buttonContainer.style.display = 'flex';
  buttonContainer.style.gap = '8px';

  group.append(categorySel, skillSel, buttonContainer);
  container.appendChild(group);

  saveSkillsToStorage();
  updateAssessmentButtons();
  checkIfFormCanBeSubmitted();
}

function populateSpecificSkills(categorySelect, skillSelect, selectedSkill = "") {
  const category = categorySelect.value;
  skillSelect.innerHTML = '<option disabled selected value="">Specific Skill</option>';
  (skillsByCategory[category] || []).forEach(skill => {
    const opt = document.createElement('option');
    opt.value = skill;
    opt.text = skill;
    if (skill === selectedSkill) opt.selected = true;
    skillSelect.add(opt);
  });
}

function updateAssessmentButtons() {
  const skillGroups = document.querySelectorAll('.skills-offer');
  const mainBtnContainer = document.getElementById('main-assessment-btn');
  mainBtnContainer.innerHTML = '';

  skillGroups.forEach((group, index) => {
    const category = group.querySelector('select[name="category[]"]').value;
    const skill = group.querySelector('select[name="specific_skill[]"]').value;
    const btnContainer = group.querySelector('.assessment-button-container');
    btnContainer.innerHTML = '';

    if (category && skill) {
      if (assessmentResults[category]?.[skill]) {
        const badge = document.createElement('span');
        badge.className = 'badge badge-primary';
        badge.textContent = assessmentResults[category][skill];
        if (skillGroups.length === 1) {
          mainBtnContainer.innerHTML = '';
          mainBtnContainer.appendChild(badge);
          mainBtnContainer.style.display = 'flex';
        } else {
          btnContainer.appendChild(badge);
        }
        group.querySelectorAll('select').forEach(s => s.disabled = true);
      } else {
        const assessBtn = document.createElement('button');
        assessBtn.type = 'button';
        assessBtn.className = 'skills-btn individual-assessment-btn';
        assessBtn.textContent = 'Take Initial Assessment';
        assessBtn.onclick = () => {
          const form = document.createElement('form');
          form.method = 'POST';
          form.action = 'initial_assessment.php';
          form.innerHTML = `<input type="hidden" name="category[]" value="${category}">
                            <input type="hidden" name="specific_skill[]" value="${skill}">`;
          document.body.appendChild(form);
          form.submit();
        };

        if (skillGroups.length === 1) {
          mainBtnContainer.appendChild(assessBtn);
          mainBtnContainer.style.display = 'flex';
        } else {
          btnContainer.appendChild(assessBtn);
          const removeBtn = document.createElement('button');
          removeBtn.type = 'button';
          removeBtn.className = 'remove-btn';
          removeBtn.textContent = '❌';
          removeBtn.onclick = () => {
            group.remove();
            if (document.querySelectorAll('.skills-offer').length === 0) addSkillSet();
            saveSkillsToStorage();
            updateAssessmentButtons();
            checkIfFormCanBeSubmitted();
          };
          btnContainer.appendChild(removeBtn);
        }
      }
    }
  });

  if (skillGroups.length > 1) {
    mainBtnContainer.style.display = 'none';
  }
  checkIfFormCanBeSubmitted();
}

function checkIfFormCanBeSubmitted() {
  const skillGroups = document.querySelectorAll('.skills-offer');
  let hasPendingAssessment = false;

  skillGroups.forEach(group => {
    const category = group.querySelector('select[name="category[]"]').value;
    const skill = group.querySelector('select[name="specific_skill[]"]').value;
    if (category && skill) {
      if (!assessmentResults[category] || !assessmentResults[category][skill]) {
        hasPendingAssessment = true;
      }
    } else {
      hasPendingAssessment = true;
    }
  });
  document.getElementById('submit-btn').disabled = hasPendingAssessment;
}

function saveSkillsToStorage() {
  const skills = [];
  document.querySelectorAll('.skills-offer').forEach(group => {
    skills.push({
      category: group.querySelector('select[name="category[]"]').value,
      skill: group.querySelector('select[name="specific_skill[]"]').value
    });
  });
  localStorage.setItem('skills-offer-data', JSON.stringify(skills));
}
</script>



</body>
</html>

