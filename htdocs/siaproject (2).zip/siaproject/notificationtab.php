<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <title>SkillSynergy Notification</title>
    <style>
        body {
            min-height: 100vh;
            background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
            background-image: url('S3.jpg');
            background-repeat: no-repeat;
            background-size: 100% 100%;
            background-position: center;
            background-attachment: fixed;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: row; 
            justify-content: flex-start;
            overflow: hidden;
        }

        .sidebar {
            position: fixed;
            top: 50px;
            left: 75px;
            width: 250px;
            height: 80vh;
            background: rgba(206, 204, 204, 0.7);
            backdrop-filter: blur(10px);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px 0;
            border-radius: 20px;
            box-shadow:
                5px 5px rgba(0, 0, 0, 0.4),
                -3px -5px rgba(255, 255, 255, 0.8);
        }

        .logo img {
            width: 100%;
            height: 120%;
            margin-top: 30px;
            object-fit: cover;
        }

        .sidebar a {
            color: #000;
            font-size: 20px;
            margin-top: 50px;
            margin: 10px 0px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 10px 20px;
            width: 200px;
            border-radius: 12px;
            transition: background 0.3s, color 0.3s;
        }

        .sidebar a i {
            font-size: 22px;
        }

        .sidebar a:hover {
            background: #007BFF;
            color: #fff;
        }

        .sidebar a.active {
            position: relative;
            font-weight: bold;
            color: #007BFF;
        }

        .sidebar a.active::after {
            content: "";
            position: absolute;
            bottom: 5px;
            left: 20px;
            width: 80%;
            height: 3px;
            background-color: #007BFF;
            border-radius: 5px;
        }

        .profile-dropdown {
            position: fixed;
            top: 20px;
            right: 80px;
            text-align: center;
        }

        .profile-container {
            position: relative;
            width: 50px;
            height: 50px;
            cursor: pointer;
        }

        .profile-icon {
            width: 45px;
            height: 45px;
            background: #004466;
            color: #fff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            transition: 0.8s;
        }

        .profile-icon:hover {
            background: #007BFF;
        }

        .arrow-icon {
            position: absolute;
            bottom: 0px;
            right: 0px;
            background-color:rgb(7, 0, 0);
            color:rgb(12, 105, 199);
            border-radius: 50%;
            width: 16px;
            height: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            margin-top: 5px;
            background:rgba(218, 214, 214, 0.88);
            min-width: 120px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
            z-index: 1;
            box-shadow:
                5px 5px rgba(0, 0, 0, 0.4),
                -3px -5px rgba(255, 255, 255, 0.8);  
        }

        .dropdown-content a {
            padding: 12px 16px;
            display: block;
            text-decoration: none;
            color: #333;
            font-weight: bold;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .profile-dropdown:hover .dropdown-content {
            display: block;
        }

        .main-content {
            flex: 1;
            padding: 40px 50px;
            overflow-y: auto;
            width: calc(100vh - 250px); 
            margin-left: 300px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 30px;
        }

        .right-section {
            width: 90%;
            display: flex;
            flex-direction: column;
            align-items: center;
            background: rgba(255, 255, 255, 0.7);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 5px 5px rgba(0, 0, 0, 0.2);
        }

        .section-title {
            font-size: 24px;
            margin-bottom: 20px;
            font-weight: bold;
            text-align: left; 
            width: 100%; 
        }

        .person-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            width: 100%;
        }
        .person-card {
            background: #fff;
            padding: 15px;
            text-align: center;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 200px;
        }

        .person-card:hover {
            transform: scale(1.05); 
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); 
        }

        .person-card img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .person-card .name-course {
            font-size: 14px;
            color: #333;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            max-width: 350px;
            width: 90%;
            position: relative;
        }

        .modal-content img {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            margin-bottom: 15px;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 30px;
            color: #000;
            cursor: pointer;
        }

        .close-btn:hover {
            color: red;
        }

        .modal-actions {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }

        .modal-actions button {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 2px solid #004466;
            background: white;
            color: #004466;
            font-size: 22px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.3s;
        }

        .modal-actions button:hover {
            background: #007BFF;
            color: #fff;
        }

    </style>
</head>
<body>

<?php
  $current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
  <div class="logo">
    <img src="logo-profilepage.jpg" alt="Logo">
  </div>
  <br><br><br><br>

  <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>" title="Home">
    <i class="fas fa-home"></i> Home
  </a>
  
  <a href="#" class="<?= $current_page == 'find_match.php' ? 'active' : '' ?>" title="Find Match">
    <i class="fas fa-search"></i> Find Match
  </a>
  
  <a href="notificationtab.php" class="<?= $current_page == 'notificationtab.php' ? 'active' : '' ?>" title="Notifications">
    <i class="fas fa-bell"></i> Notification
  </a>
  
  <a href="matched_tab.php" class="<?= $current_page == 'matched_tab.php' ? 'active' : '' ?>" title="Matched Users">
    <i class="fas fa-user-friends"></i> Matched
  </a>
  
  <a href="message.php" class="<?= $current_page == 'message.php' ? 'active' : '' ?>" title="Messages">
    <i class="fas fa-comment-dots"></i> Message
  </a>
</div>

<div class="main-content">
    <div class="right-section">
        <div class="section-title">People who want to learn with you</div>
        <div class="person-grid">

          <div class="person-card" onclick="showDetails('Maricar Reducto', 'BSIT ', 'Maricar.jpg', 'learning')">
            <img src="Maricar.jpg" alt="User 1">
            <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
            <div class="name-course">Maricar Reducto, Course</div>
        </div>

        <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'learning')">
            <img src="user1.jpg" alt="User 1">
            <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
            <div class="name-course">Name, Course</div>
        </div>

        <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'learning')">
            <img src="user1.jpg" alt="User 1">
            <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
            <div class="name-course">Name, Course</div>
        </div>

        <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'learning')">
            <img src="user1.jpg" alt="User 1">
            <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
            <div class="name-course">Name, Course</div>
        </div>

           
        </div>
        <br>
        <div class="section-title">People you liked</div>
        <div class="person-grid">
            <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'liked')">
                <img src="user1.jpg" alt="User 1">
                <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
                <div class="name-course">Name, Course</div>
            </div>

            <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'liked')">
                <img src="user1.jpg" alt="User 1">
                <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
                <div class="name-course">Name, Course</div>
            </div>

            <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'liked')">
                <img src="user1.jpg" alt="User 1">
                <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
                <div class="name-course">Name, Course</div>
            </div>

            <div class="person-card" onclick="showDetails('Name', 'Course ', 'user1.jpg', 'liked')">
                <img src="user1.jpg" alt="User 1">
                <div style="width: 300px; height: 1px; background-color: #ccc; margin-top: 5px;"></div>
                <div class="name-course">Name, Course</div>
            </div>
            
        </div>
    </div>
</div>

<div id="modal" class="modal">
  <div class="modal-content">
    <span class="close-btn" onclick="closeModal()">&times;</span>
    <img id="user-image" src="" alt="">
    <h2 id="user-name"></h2>
    <p id="user-course"></p>
    <div class="modal-actions">
      <button onclick="removeAction()"><i class="fas fa-thumbs-down"></i></button>
      <button onclick="confirmAction()"><i class="fas fa-thumbs-up"></i></button>
    </div>
  </div>
</div>

<script>
function showDetails(name, course, image, section) {
  document.getElementById("modal").style.display = "flex";
  document.getElementById("user-name").innerText = name;
  document.getElementById("user-course").innerText = course;
  document.getElementById("user-image").src = image;

  const actions = document.querySelector('.modal-actions');
  if (section === 'liked') {
    actions.children[1].style.display = 'none';
  } else {
    actions.children[1].style.display = 'flex';
  }
}

function closeModal() {
  document.getElementById("modal").style.display = "none";
}

function confirmAction() {
  alert("Confirmed!");
  closeModal();
}

function removeAction() {
  alert("Removed!");
  closeModal();
}
</script>

</body>
</html>