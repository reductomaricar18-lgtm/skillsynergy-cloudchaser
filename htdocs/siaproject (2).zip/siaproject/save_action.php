<?php
session_start();

// Validate session
if (!isset($_SESSION['email'])) {
    http_response_code(403);
    echo "Unauthorized";
    exit();
}

// DB connection
$conn = new mysqli("localhost", "root", "", "sia1");
if ($conn->connect_error) {
    http_response_code(500);
    echo "Database connection failed";
    exit();
}

// Get POST data
$email = $_SESSION['email'];
$action = $_POST['action'] ?? '';
$liked_user_id = intval($_POST['liked_user_id'] ?? 0);

// Validate inputs
if (!in_array($action, ['like', 'dislike']) || $liked_user_id <= 0) {
    http_response_code(400);
    echo "Invalid input";
    exit();
}

// Get current user ID
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($user_id);
$stmt->fetch();
$stmt->close();

if (!$user_id) {
    http_response_code(404);
    echo "User not found";
    exit();
}

// Check if action already exists
$stmt = $conn->prepare("SELECT id FROM user_likes WHERE user_id = ? AND liked_user_id = ?");
$stmt->bind_param("ii", $user_id, $liked_user_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    $stmt->close();

    // Insert new like/dislike
    $stmt = $conn->prepare("INSERT INTO user_likes (user_id, liked_user_id, action, timestamp) VALUES (?, ?, ?, NOW())");
    $stmt->bind_param("iis", $user_id, $liked_user_id, $action);

    if ($stmt->execute()) {
        echo "Action recorded: $action";
    } else {
        http_response_code(500);
        echo "Failed to insert action";
    }

    $stmt->close();
} else {
    echo "Already recorded";
}

$conn->close();
?>
