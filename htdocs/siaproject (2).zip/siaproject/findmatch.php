<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Get current user info
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($user_id);
$stmt->fetch();
$stmt->close();

$matches = [];

// Get current user's skills and proficiencies
$userSkills = [];
$result = $conn->query("SELECT skill, proficiency FROM initial_assessment WHERE user_id = $user_id");
while ($row = $result->fetch_assoc()) {
    $userSkills[$row['skill']] = $row['proficiency'];
}

// Match users with similar skills and close location/age/availability, excluding already liked/disliked users
$query = "
    SELECT u.user_id, up.first_name, up.last_name, up.age, up.location, up.availability, 
           ia.skill, ia.proficiency, ed.course, so.specific_skill
    FROM users u
    JOIN users_profile up ON u.user_id = up.user_id
    JOIN initial_assessment ia ON u.user_id = ia.user_id
    LEFT JOIN education ed ON u.user_id = ed.user_id
    LEFT JOIN skills_offer so ON u.user_id = so.user_id
    WHERE u.user_id != $user_id
      AND u.user_id NOT IN (
          SELECT liked_user_id FROM user_likes WHERE user_id = $user_id
      )
";

$res = $conn->query($query);

$candidates = [];
while ($row = $res->fetch_assoc()) {
    $uid = $row['user_id'];
    if (!isset($candidates[$uid])) {
        $candidates[$uid] = [
            'user_id' => $uid,
            'name' => $row['first_name'] . ' ' . $row['last_name'],
            'age' => $row['age'],
            'location' => $row['location'],
            'availability' => $row['availability'],
            'course' => $row['course'],
            'specific_skill' => $row['specific_skill'],
            'skills' => [],
        ];
    }
    $candidates[$uid]['skills'][$row['skill']] = $row['proficiency'];
}

// Scoring system
foreach ($candidates as $candidate) {
    $score = 0;
    foreach ($candidate['skills'] as $skill => $proficiency) {
        if (isset($userSkills[$skill])) {
            $score += ($userSkills[$skill] === $proficiency) ? 2 : 1;
        }
    }

    // Filters: age ±5, same location, same availability
    if (abs($candidate['age'] - $_SESSION['profile_age']) <= 5) $score++;
    if ($candidate['location'] === $_SESSION['profile_location']) $score++;
    if ($candidate['availability'] === $_SESSION['profile_availability']) $score++;

    if ($score > 2) {
        $matches[] = [
            'user_id' => $candidate['user_id'],
            'name' => $candidate['name'],
            'icon' => '👤',
            'score' => $score,
            'course' => $candidate['course'],
            'specific_skill' => $candidate['specific_skill']
        ];
    }
}

shuffle($matches);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SkillSynergy Find Match</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      min-height: 100vh;
      background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
      background-image: url('S3.jpg');
      background-repeat: no-repeat;
      background-size: 100% 100%;
      background-position: center;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
    }

    .sidebar {
      position: fixed;
      top: 100px;
      left: 75px;
      width: 300px;
      height: 80vh;
      background: rgba(206, 204, 204, 0.7);
      backdrop-filter: blur(10px);
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 20px 0;
      border-radius: 20px;
      box-shadow: 5px 5px rgba(0, 0, 0, 0.4), -3px -5px rgba(255, 255, 255, 0.8);
    }

    .logo img {
      width: 100%;
      height: 120%;
      margin-top: 30px;
      object-fit: cover;
    }

    .sidebar a {
      color: #000;
      font-size: 20px;
      margin: 10px 0px;
      text-decoration: none;
      display: flex;
      align-items: center;
      gap: 15px;
      padding: 10px 20px;
      width: 200px;
      border-radius: 12px;
      transition: background 0.3s, color 0.3s;
    }

    .sidebar a i { font-size: 22px; }

    .sidebar a:hover {
      background: #007BFF;
      color: #fff;
    }

    .profile-dropdown {
      position: fixed;
      top: 20px;
      right: 80px;
      text-align: center;
    }

    .profile-container {
      position: relative;
      width: 50px;
      height: 50px;
      cursor: pointer;
    }

    .profile-icon {
      width: 45px;
      height: 45px;
      background: #004466;
      color: #fff;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      transition: 0.8s;
    }

    .profile-icon:hover { background: #007BFF; }

    .arrow-icon {
      position: absolute;
      bottom: 0px;
      right: 0px;
      background-color: rgb(7, 0, 0);
      color: rgb(12, 105, 199);
      border-radius: 50%;
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    }

    .dropdown-content {
      display: none;
      position: absolute;
      right: 0;
      margin-top: 10px;
      background: rgba(218, 214, 214, 0.88);
      min-width: 120px;
      border-radius: 8px;
      overflow: hidden;
      z-index: 1;
      box-shadow: 5px 5px rgba(0, 0, 0, 0.4), -3px -5px rgba(255, 255, 255, 0.8);
    }

    .dropdown-content a {
      padding: 12px 16px;
      display: block;
      text-decoration: none;
      color: #333;
      font-weight: bold;
    }

    .dropdown-content a:hover { background-color: #ddd; }
    .profile-dropdown:hover .dropdown-content { display: block; }

    .main {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 20px;
      margin-left: 350px;
      padding: 30px 0;
      position: relative;
    }

    .search-bar {
      background: rgba(255, 255, 255, 0.3);
      backdrop-filter: blur(8px);
      border-radius: 30px;
      padding: 8px 16px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.15);
      display: flex;
      align-items: center;
      width: 300px;
    }

    .search-bar input {
      background: transparent;
      border: none;
      outline: none;
      font-size: 16px;
      width: 100%;
      color: #333;
      padding-left: 10px;
    }

    .ghost-card {
      position: absolute;
      width: 300px;
      height: 450px;
      background: rgba(255, 255, 255, 0.15);
      border-radius: 25px;
      backdrop-filter: blur(15px);
      z-index: 0;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    .bg-glass-left {
      transform: rotate(-4deg);
      left: -200px;
      margin-top: 80px;
      z-index: 0;
    }

    .bg-glass-right {
      transform: rotate(4deg);
      right: -200px;
      margin-top: 80px;
      z-index: 0;
    }

    .card-container {
      width: 400px;
      height: 500px;
      background: rgba(255, 255, 255, 0.25);
      backdrop-filter: blur(12px);
      border-radius: 25px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: space-between;
      padding: 25px 20px 80px;
      text-align: center;
      position: relative;
      border: 1px solid rgba(255, 255, 255, 0.4);
      z-index: 1;
      transition: transform 0.4s ease, opacity 0.4s ease;
    }

    .card-container.swipe-left { transform: translateX(-500px) rotate(-20deg); opacity: 0; }
    .card-container.swipe-right { transform: translateX(500px) rotate(20deg); opacity: 0; }

    .profile-pic {
      width: 100%;
      height: 250px;
      border-radius: 15px;
      background: linear-gradient(to top, #e3f2fd, #ffffff);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 50px;
      color: #aaa;
    }

    .profile-name {
      font-size: 20px;
      font-weight: bold;
      color: #333;
    }

    .action-buttons {
      position: absolute;
      bottom: -40px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 20px;
      z-index: 2;
    }

    .action-buttons button {
      width: 70px;
      height: 70px;
      border-radius: 50%;
      background: #000;
      color: #fff;
      border: 4px solid #fff;
      font-size: 28px;
      cursor: pointer;
      transition: transform 0.2s ease;
    }

    .action-buttons button:hover {
      transform: scale(1.1);
      background: #333;
    }

    .sidebar a.active {
      position: relative;
      font-weight: bold;
      color: #007BFF;
    }

    .sidebar a.active::after {
      content: "";
      position: absolute;
      bottom: 5px;
      left: 20px;
      width: 80%;
      height: 3px;
      background-color: #007BFF;
      border-radius: 5px;
    }

.card-container.swipe-left {
  transform: translateX(-500px) rotate(-15deg);
  opacity: 0;
  transition: 0.4s ease;
}

.card-container.swipe-right {
  transform: translateX(500px) rotate(15deg);
  opacity: 0;
  transition: 0.4s ease;
}

  </style>
</head>
<body>

<?php
  $current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="sidebar">
  <div class="logo">
    <img src="logo-profilepage.jpg" alt="Logo">
  </div>
  <br><br><br>

  <a href="dashboard.php" class="<?= $current_page == 'dashboard.php' ? 'active' : '' ?>" title="Home">
    <i class="fas fa-home"></i> Home
  </a>
  
  <a href="findmatch.php" class="<?= $current_page == 'findmatch.php' ? 'active' : '' ?>" title="Find Match">
    <i class="fas fa-search"></i> Find Match
  </a>
  
  <a href="notificationtab.php" class="<?= $current_page == 'notificationtab.php' ? 'active' : '' ?>" title="Notifications">
    <i class="fas fa-bell"></i> Notification
  </a>
  
  <a href="matched_tab.php" class="<?= $current_page == 'matched_tab.php' ? 'active' : '' ?>" title="Matched Users">
    <i class="fas fa-user-friends"></i> Matched
  </a>
  
  <a href="message.php" class="<?= $current_page == 'message.php' ? 'active' : '' ?>" title="Messages">
    <i class="fas fa-comment-dots"></i> Message
  </a>
</div>

<div class="profile-dropdown">
  <div class="profile-container">
    <div class="profile-icon"><i class="fas fa-user"></i></div>
    <div class="arrow-icon"><i class="fas fa-caret-down"></i></div>
  </div>
  <div class="dropdown-content">
    <a href="user_profile.php">Profile</a>
    <a href="logout.php">Log Out</a>
  </div>
</div>

<div class="main">
  <div class="search-bar">
    <i class="fas fa-search"></i>
    <input type="text" id="searchInput" placeholder="Search...">
    <div class="search-history" id="searchHistory"></div>
  </div>

  <div class="ghost-card bg-glass-left"></div>
  <div class="ghost-card bg-glass-right"></div>

  <div class="card-container" id="card">
    <div class="profile-pic" id="profilePic">👤</div>
    <div class="profile-name" id="profileName">Loading...</div>
  <div class="action-buttons">
    <button onclick="swipe('dislike')"><i class="fas fa-thumbs-down"></i></button>
    <button onclick="swipe('like')"><i class="fas fa-thumbs-up"></i></button>
  </div>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const profiles = <?php echo json_encode($matches); ?>;
  let currentIndex = 0;

  const profilePic = document.getElementById("profilePic");
  const profileName = document.getElementById("profileName");
  const card = document.getElementById("card");
  const buttons = document.querySelector(".action-buttons");

  function loadProfile(index) {
    const profile = profiles[index];
    if (!profile) return;

    profilePic.textContent = profile.icon;
    profileName.innerHTML = `
      <strong>${profile.name}</strong><br>
      ID: ${profile.user_id}<br>
      Match Score: ${profile.score}
    `;
  }

  window.swipe = function(direction) {
    if (currentIndex >= profiles.length) return;
    const profile = profiles[currentIndex];

    // Add swipe animation
    card.classList.remove("swipe-left", "swipe-right");
    void card.offsetWidth; // force reflow
    card.classList.add(direction === "like" ? "swipe-right" : "swipe-left");

    // Send action to PHP
    fetch("save_action.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: `action=${direction}&liked_user_id=${profile.user_id}`
    }).then(response => response.text())
      .then(data => console.log("Server:", data))
      .catch(err => console.error("Error:", err));

    setTimeout(() => {
      currentIndex++;
      if (currentIndex < profiles.length) {
        loadProfile(currentIndex);
        card.classList.remove("swipe-left", "swipe-right");
      } else {
        profilePic.textContent = "😊";
        profileName.textContent = "No more matches!";
        buttons.style.display = "none";
      }
    }, 400);
  }

  loadProfile(currentIndex);
});
</script>


</body>
</html>
