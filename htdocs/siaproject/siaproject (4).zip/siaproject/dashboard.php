<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SkillSynergy Dashboard/Leaderboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      min-height: 100vh;
      background: linear-gradient(to bottom right, #cce7ff, #e2e2ff);
      background-image: url('S3.jpg');
      background-repeat: no-repeat;
      background-size: 100% 100%;
      background-position: center;
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
    }

.sidebar {
  position: fixed;
  top: 100px;
  left: 75px;
  width: 250px;
  height: 80vh;
  background: rgba(206, 204, 204, 0.7);
  backdrop-filter: blur(10px);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
  border-radius: 20px;
  box-shadow:
    5px 5px rgba(0, 0, 0, 0.4),
    -3px -5px rgba(255, 255, 255, 0.8);
}

.logo img {
  width: 100%;
  height: 120%;
  margin-top: 30px;
  object-fit: cover;
}

.sidebar a {
  color: #000;
  font-size: 20px;
  margin-top: 50px;
  margin: 10px 0px;
  text-decoration: none;
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 10px 20px;
  width: 200px;
  border-radius: 12px;
  transition: background 0.3s, color 0.3s;
}

.sidebar a i {
  font-size: 22px;
}

.sidebar a:hover {
  background: #007BFF;
  color: #fff;
}

    .profile-dropdown {
      position: fixed;
      top: 20px;
      right: 80px;
      text-align: center;
    }

    .profile-container {
      position: relative;
      width: 50px;
      height: 50px;
      cursor: pointer;
    }

    .profile-icon {
      width: 45px;
      height: 45px;
      background: #004466;
      color: #fff;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      transition: 0.8s;
    }

    .profile-icon:hover {
      background: #007BFF;
    }

    .arrow-icon {
      position: absolute;
      bottom: 0px;
      right: 0px;
      background-color:rgb(7, 0, 0);
      color:rgb(12, 105, 199);
      border-radius: 50%;
      width: 16px;
      height: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 10px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.2);
    }

    .dropdown-content {
      display: none;
      position: absolute;
      right: 0;
      margin-top: 10px;
      background:rgba(218, 214, 214, 0.88);
      min-width: 120px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      border-radius: 8px;
      overflow: hidden;
      z-index: 1;
      box-shadow:
      5px 5px rgba(0, 0, 0, 0.4),    /* bottom-right black shadow */
      -3px -5px rgba(255, 255, 255, 0.8); /* top-left white glow */  
    }

    .dropdown-content a {
      padding: 12px 16px;
      display: block;
      text-decoration: none;
      color: #333;
      font-weight: bold;
    }

    .dropdown-content a:hover {
      background-color: #ddd;
    }

    .profile-dropdown:hover .dropdown-content {
      display: block;
    }

.main-content {
  flex: 1;
  padding: 40px 50px;
  overflow-y: auto;
  width: 100vh;
  box-sizing: border-box;
}

.header {
  display: flex;
  justify-content: flex-end;
  align-items: center;
}

.profile-pic img {
  width: 65px;
  height: 65px;
  border-radius: 50%;
  border: 3px solid #fff;
  box-shadow: 0 0 8px rgba(0,0,0,0.2);
}

.leaderboard-wrapper {
  background: rgba(255, 255, 255, 0.25);
  backdrop-filter: blur(15px);
  -webkit-backdrop-filter: blur(15px);
  border-radius: 30px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
  padding: 30px;
  max-width: 1750px;
  margin: 30px auto;
  height: 650px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
}

.leaderboard-section {
  margin-top: 0;
  max-width: 100%;
  margin-left: 0;
  margin-right: 0;
}

.leaderboard {
  background: rgba(255, 255, 255, 0.6);
  padding: 40px;
  border-radius: 25px;
  margin-bottom: 40px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.leaderboard h2 {
  font-size: 26px;
  margin-left: 200px;
  font-weight: 700;
  text-align: left;
}

.leaderboard select {
  padding: 12px 20px;
  border-radius: 15px;
  border: 1px solid #ccc;
  font-size: 16px;
  margin-top: 10px;
  display: inline-block;
}

.avatar-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(80px, 1fr));
  gap: 25px;
  margin-top: 30px;
  justify-items: center;
}

.avatar {
  width: 80px;
  height: 80px;
  background: url('avatar-placeholder.png') center/cover no-repeat;
  border-radius: 50%;
  border: 3px solid #ccc;
}

.footer-links {
  display: flex;
  justify-content: center;
  gap: 25px;
  margin-top: 40px;
}

.footer-links a {
  text-decoration: none;
  color: #333;
  background: rgba(255,255,255,0.6);
  padding: 12px 25px;
  border-radius: 15px;
  font-weight: 600;
  transition: background 0.3s;
}

.footer-links a:hover {
  background: rgba(255,255,255,0.8);
}
  </style>
</head>
<body>

<div class="sidebar">
  <div class="logo">
    <img src="logo-profilepage.jpg" alt="Logo">
  </div>
  <br><br><br><br>

  <a href="dashboard.php" title="Home">
    <i class="fas fa-home"></i> Home
  </a>
  
  <a href="#" title="Find Match">
    <i class="fas fa-search"></i> Find Match
  </a>
  
  <a href="notificationtab.php" title="Notifications">
    <i class="fas fa-bell"></i> Notification
  </a>
  
  <a href="#" title="Matched Users">
    <i class="fas fa-user-friends"></i> Matched
  </a>
  
  <a href="#" title="Messages">
    <i class="fas fa-comment-dots"></i> Message
  </a>
</div>

  <div class="profile-dropdown">
    <div class="profile-container">
      <div class="profile-icon">
        <i class="fas fa-user"></i>
      </div>
      <div class="arrow-icon"><i class="fas fa-caret-down"></i></div>
    </div>
    <div class="dropdown-content">
      <a href="user_profile.php">Profile</a>
      <a href="logout.php">Log Out</a>
    </div>
  </div>

<div class="main-content">
  <div class="leaderboard-wrapper">
    <div class="leaderboard-section">
      <div class="leaderboard">
        <select>
          <option>Select Skill</option>
          <option>Web Development</option>
          <option>Graphic Design</option>
          <option>Video Editing</option>
        </select>
        <h2>Skill Leaderboard: RANK I</h2>
        <div class="avatar-grid">
          <!-- 12 avatars -->
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
        </div>
      </div>

      <div class="leaderboard">
        <select>
          <option>Select Skill</option>
        </select>
        <h2>Tutor Leaderboard: RANK I</h2>
        <div class="avatar-grid">
          <!-- 12 avatars -->
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
          <div class="avatar"></div>
        </div>
      </div>
    </div>
  </div>

    <div class="footer-links">
      <a href="#">FAQs</a>
      <a href="#">MANUAL</a>
    </div>
</div>

</body>
</html>