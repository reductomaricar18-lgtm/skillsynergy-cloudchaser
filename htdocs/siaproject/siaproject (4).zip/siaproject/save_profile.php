<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_SESSION['email'];

// Get user_id
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($user_id);
if (!$stmt->fetch()) {
    $stmt->close();
    $conn->close();
    header("Location: login.php");
    exit();
}
$stmt->close();

// Personal Info
$last_name = trim($_POST['last_name'] ?? $_SESSION['profile-setup-form']['last_name']);
$first_name = trim($_POST['first_name'] ?? $_SESSION['profile-setup-form']['first_name']);
$middle_initial = trim($_POST['middle_initial'] ?? $_SESSION['profile-setup-form']['middle_initial']);
$suffix = trim($_POST['suffix'] ?? $_SESSION['profile-setup-form']['suffix']);
$location = trim($_POST['location'] ?? $_SESSION['profile-setup-form']['location']);
$gender = trim($_POST['gender'] ?? $_SESSION['profile-setup-form']['gender']);
$age = intval($_POST['age'] ?? $_SESSION['profile-setup-form']['age']);
$availability = trim($_POST['availability'] ?? $_SESSION['profile-setup-form']['availability']);
$bio = trim($_POST['bio'] ?? $_SESSION['profile-setup-form']['bio']);

// Check if personal profile exists
$checkProfile = $conn->prepare("SELECT profile_id FROM users_profile WHERE user_id = ?");
$checkProfile->bind_param("i", $user_id);
$checkProfile->execute();
$checkProfile->store_result();

if ($checkProfile->num_rows > 0) {
    $checkProfile->bind_result($profile_id);
    $checkProfile->fetch();
    $checkProfile->close();

    $stmtProfile = $conn->prepare("UPDATE users_profile SET last_name=?, first_name=?, middle_initial=?, suffix=?, location=?, gender=?, age=?, availability=?, bio=? WHERE user_id=?");
    $stmtProfile->bind_param("ssssssissi", $last_name, $first_name, $middle_initial, $suffix, $location, $gender, $age, $availability, $bio, $user_id);
} else {
    $checkProfile->close();
    $stmtProfile = $conn->prepare("INSERT INTO users_profile (user_id, last_name, first_name, middle_initial, suffix, location, gender, age, availability, bio) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmtProfile->bind_param("issssssiss", $user_id, $last_name, $first_name, $middle_initial, $suffix, $location, $gender, $age, $availability, $bio);
}
$stmtProfile->execute();
$stmtProfile->close();

// Education Section
$college = trim($_POST['college'] ?? $_SESSION['profile-setup-form']['college']);
$course = trim($_POST['course'] ?? $_SESSION['profile-setup-form']['course']);
$status = trim($_POST['status'] ?? $_SESSION['profile-setup-form']['status']);
$year = trim($_POST['year'] ?? $_SESSION['profile-setup-form']['year']);
$block = trim($_POST['block'] ?? $_SESSION['profile-setup-form']['block']);

$checkEducation = $conn->prepare("SELECT education_id FROM education WHERE user_id = ?");
$checkEducation->bind_param("i", $user_id);
$checkEducation->execute();
$checkEducation->store_result();

if ($checkEducation->num_rows > 0) {
    $checkEducation->bind_result($education_id);
    $checkEducation->fetch();
    $checkEducation->close();

    $stmtEducation = $conn->prepare("UPDATE education SET college=?, course=?, status=?, year=?, block=? WHERE user_id=?");
    $stmtEducation->bind_param("sssssi", $college, $course, $status, $year, $block, $user_id);
} else {
    $checkEducation->close();
    $stmtEducation = $conn->prepare("INSERT INTO education (user_id, college, course, status, year, block) VALUES (?, ?, ?, ?, ?, ?)");
    $stmtEducation->bind_param("isssss", $user_id, $college, $course, $status, $year, $block);
}
$stmtEducation->execute();
$stmtEducation->close();

// Skills Offer Section
if (!empty($_POST['category']) && !empty($_POST['specific_skill'])) {
    $categories = $_POST['category'];
    $specificSkills = $_POST['specific_skill'];

    if (count($categories) == count($specificSkills)) {
        // Clear old skills for this user
        $conn->query("DELETE FROM skills_offer WHERE user_id = " . intval($user_id));

        for ($i = 0; $i < count($categories); $i++) {
            $category = trim($categories[$i]);
            $specific_skill = trim($specificSkills[$i]);

            if ($category !== '' && $specific_skill !== '') {
                $stmtSkill = $conn->prepare("INSERT INTO skills_offer (user_id, category, specific_skill) VALUES (?, ?, ?)");
                $stmtSkill->bind_param("iss", $user_id, $category, $specific_skill);
                $stmtSkill->execute();
                $stmtSkill->close();
            }
        }
    }
}

// Initial Assessments Section
if (!empty($_SESSION['categories']) && !empty($_SESSION['specific_skills']) && !empty($_POST['assessment_scores'])) {
    $assessmentCategories = $_SESSION['categories'];
    $assessmentSkills = $_SESSION['specific_skills'];
    $assessmentScores = $_POST['assessment_scores'];

    if (count($assessmentCategories) == count($assessmentSkills) && count($assessmentCategories) == count($assessmentScores)) {
        for ($i = 0; $i < count($assessmentCategories); $i++) {
            $selectedCategory = $conn->real_escape_string($assessmentCategories[$i]);
            $selectedSkill = $conn->real_escape_string($assessmentSkills[$i]);
            $score = intval($assessmentScores[$i]);

            // Example: total items is 20
            $total = 20;

            // Determine proficiency
            $proficiency = ($score / $total) >= 0.85 ? 'Advanced' :
                           (($score / $total) >= 0.65 ? 'Intermediate' : 'Beginner');

            // Insert into initial_assessment table
            $stmtIA = $conn->prepare("INSERT INTO initial_assessment (user_id, category, skill, score, total_items, proficiency)
                                      VALUES (?, ?, ?, ?, ?, ?)");
            $stmtIA->bind_param("issiis", $user_id, $selectedCategory, $selectedSkill, $score, $total, $proficiency);
            $stmtIA->execute();
            $stmtIA->close();
        }
    }

    // Clear assessment session vars
    unset($_SESSION['categories']);
    unset($_SESSION['specific_skills']);
}

// Mark profile as completed
$updateCompleted = $conn->prepare("UPDATE users SET profile_completed = 1 WHERE user_id = ?");
$updateCompleted->bind_param("i", $user_id);
$updateCompleted->execute();
$updateCompleted->close();

$conn->close();
header("Location: profile_page.php");
exit();
?>