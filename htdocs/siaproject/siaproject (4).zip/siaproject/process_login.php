<?php
ob_start();
session_start();

$conn = new mysqli('localhost', 'root', '', 'sia1');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Collect form inputs
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Check if email and password are not empty
if (empty($email) || empty($password)) {
    $_SESSION['login_error'] = "Please enter both username and password.";
    header("Location: login.php");
    exit;
}

// Validate email format
if (!preg_match("/^[a-zA-Z0-9._%+-]+@plm\.edu\.ph$/", $email)) {
    $_SESSION['email_error'] = 'Please enter a valid PLM email address (e.g., yourname@plm.edu.ph).';
    header("Location: login.php");
    exit;
}

// Check if the user exists with given email and password
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND password = ?");
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();

    $_SESSION['email'] = $email;
    $_SESSION['user_id'] = $user['user_id']; // Store user ID in session for other pages

    if ($user['profile_completed'] == 1) {
        header("Location: dashboard.php"); // Redirect to dashboard if profile setup is complete
    } else {
        header("Location: profile_setup.php"); // Else, redirect to profile setup
    }
    exit;
} else {
    // Check if email exists to give specific message
    $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $checkEmail->bind_param("s", $email);
    $checkEmail->execute();
    $emailResult = $checkEmail->get_result();

    if ($emailResult->num_rows == 0) {
        $_SESSION['email_error'] = "This email does not exist.";
    } else {
        $_SESSION['login_error'] = "Invalid username or password.";
    }

    $checkEmail->close();
    header("Location: login.php");
    exit;
}

$stmt->close();
$conn->close();
ob_end_flush();
?>







